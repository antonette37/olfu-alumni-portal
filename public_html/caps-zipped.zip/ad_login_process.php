<?php

session_start();

$admin_username = 'admin'; /*default*/
$admin_password = 'password'; /*default*/

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']); 
    $password = trim($_POST['password']);

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: ad_dashboard.php');
        exit();
    } else {
        header('Location: ad_login.php?error=true');
        exit();
    }
}
?>
