<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "itcp_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$limit = 15;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($search !== '') {
    $searchTerm = "%$search%";

    $countStmt = $conn->prepare("SELECT COUNT(id) AS total FROM itcp 
        WHERE firstname LIKE ? OR lastname LIKE ? OR student_number LIKE ?");
    $countStmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
    $countStmt->execute();
    $total_result = $countStmt->get_result()->fetch_assoc();
    $countStmt->close();

    $stmt = $conn->prepare("SELECT * FROM itcp 
        WHERE firstname LIKE ? OR lastname LIKE ? OR student_number LIKE ?
        LIMIT ?, ?");
    $stmt->bind_param("sssii", $searchTerm, $searchTerm, $searchTerm, $start, $limit);
} else {
    $total_result = $conn->query("SELECT COUNT(id) AS total FROM itcp")->fetch_assoc();
    $stmt = $conn->prepare("SELECT * FROM itcp LIMIT ?, ?");
    $stmt->bind_param("ii", $start, $limit);
}

$stmt->execute();
$result = $stmt->get_result();
$total_pages = ceil($total_result['total'] / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Alumni Record</title>
    <link rel="stylesheet" href="ad_alumnirecord_csss.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Alumni Records</span>
    </div>
    <nav>
        <a href="ad_home.html">Home</a>
        <a href="ad_dashboard.php">Dashboard</a>
        <a href="#">Messages</a>
        <a href="#">Notifications</a>
        <a href="ad_logout.php">Log Out</a>
    </nav>
</div>

<h2>Admin Dashboard – Full Alumni Records</h2>

<form method="GET" action="ad_dashboard.php" class="search-form">
    <input type="text" name="search" placeholder="Search alumni..." value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
    <button type="submit">Search</button>
</form>

<table>
    <thead>
        <tr>
            <th>Photo</th>
            <th>Last Name</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Name Extension</th>
            <th>Birthday</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Civil Status</th>
            <th>Religion</th>
            <th>Nationality</th>
            <th>Personal Email</th>
            <th>Address</th>
            <th>Personal Contact</th>
            <th>Emergency Contact</th>
            <th>Student Number</th>
            <th>Program</th>
            <th>Campus</th>
            <th>Month Graduated</th>
            <th>Year Graduated</th>
            <th>Post Grad</th>
            <th>Licensure Exam</th>
            <th>Club Involvement</th>
            <th>Employment Status</th>
            <th>Company</th>
            <th>Industry</th>
            <th>Position</th>
            <th>Employment History</th>
            <th>Previous Role</th>
            <th>Length of Service</th>
            <th>Consent</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td>
                <?php if (!empty($row['photo'])): ?>
                    <img src="uploads/<?= htmlspecialchars($row['photo']) ?>" width="50" height="50">
                <?php else: ?>
                    N/A
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($row['lastname']) ?></td>
            <td><?= htmlspecialchars($row['firstname']) ?></td>
            <td><?= htmlspecialchars($row['middlename']) ?></td>
            <td><?= htmlspecialchars($row['name_ext']) ?></td>
            <td><?= htmlspecialchars($row['birthday']) ?></td>
            <td><?= htmlspecialchars($row['age']) ?></td>
            <td><?= htmlspecialchars($row['gender']) ?></td>
            <td><?= htmlspecialchars($row['civil_status']) ?></td>
            <td><?= htmlspecialchars($row['religion']) ?></td>
            <td><?= htmlspecialchars($row['nationality']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= htmlspecialchars($row['personal_contact']) ?></td>
            <td><?= htmlspecialchars($row['emergency_contact']) ?></td>
            <td><?= htmlspecialchars($row['student_number']) ?></td>
            <td><?= htmlspecialchars($row['program']) ?></td>
            <td><?= htmlspecialchars($row['campus']) ?></td>
            <td><?= htmlspecialchars($row['month_graduated']) ?></td>
            <td><?= htmlspecialchars($row['year_graduated']) ?></td>
            <td><?= htmlspecialchars($row['post_grad']) ?></td>
            <td><?= htmlspecialchars($row['licensure_exam']) ?></td>
            <td><?= htmlspecialchars($row['club_involvement']) ?></td>
            <td><?= htmlspecialchars($row['employment_status']) ?></td>
            <td><?= htmlspecialchars($row['company']) ?></td>
            <td><?= htmlspecialchars($row['industry']) ?></td>
            <td><?= htmlspecialchars($row['position']) ?></td>
            <td><?= htmlspecialchars($row['employment_history']) ?></td>
            <td><?= htmlspecialchars($row['previous_role']) ?></td>
            <td><?= htmlspecialchars($row['length_of_service']) ?></td>
            <td><?= htmlspecialchars($row['consent']) ?></td>
            <td class="action-links">
                <a href="ad_alumnirecord_edit.php?id=<?= $row['id'] ?>">Edit</a>
                <a href="ad_alumnirecord_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this record?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<div class="pagination">
    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <a href="ad_dashboard.php?page=<?= $i ?>&search=<?= urlencode($search) ?>" class="<?= ($page == $i) ? 'active' : '' ?>">
            <?= $i ?>
        </a>
    <?php endfor; ?>
</div>

</body>
</html>

<?php $stmt->close(); ?>
