<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['resume'])) {
        $file = $_FILES['resume'];
        echo json_encode([
            'success' => true,
            'message' => 'File received successfully',
            'details' => [
                'name' => $file['name'],
                'type' => $file['type'],
                'size' => $file['size'],
                'error' => $file['error'],
                'tmp_name' => $file['tmp_name']
            ]
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No file uploaded'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}
?> 