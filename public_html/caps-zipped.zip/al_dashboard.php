<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: al_homepage.php");
    exit();
}

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'itcp_db';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Get total alumni
$totalAlumni = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM itcp");
if ($result && $row = $result->fetch_assoc()) {
    $totalAlumni = $row['total'];
}

// Get total job listings
$totalJobs = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM jobs");
if ($result && $row = $result->fetch_assoc()) {
    $totalJobs = $row['total'];
}

// Get total upcoming events
$totalEvents = 0;
$today = date("Y-m-d");
$stmt = $conn->prepare("SELECT COUNT(*) AS total FROM events WHERE date >= ?");
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $row = $result->fetch_assoc()) {
    $totalEvents = $row['total'];
}
$stmt->close();

// Get total announcements
$totalAnnouncements = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM announcements");
if ($result && $row = $result->fetch_assoc()) {
    $totalAnnouncements = $row['total'];
}

// Get recent announcements
$recentAnnouncements = [];
$announcementQuery = $conn->query("SELECT title, content, date_posted FROM announcements ORDER BY date_posted DESC LIMIT 5");
if ($announcementQuery) {
    while ($row = $announcementQuery->fetch_assoc()) {
        $recentAnnouncements[] = $row;
    }
}

// Get upcoming events
$upcomingEvents = [];
$eventQuery = $conn->prepare("SELECT title, description, date, location FROM events WHERE date >= ? ORDER BY date ASC LIMIT 5");
$eventQuery->bind_param("s", $today);
$eventQuery->execute();
$eventResult = $eventQuery->get_result();
if ($eventResult) {
    while ($row = $eventResult->fetch_assoc()) {
        $upcomingEvents[] = $row;
    }
}
$eventQuery->close();

// Alumni by graduation year
$alumniByYear = [];
$chartQuery = $conn->query("SELECT year_graduated AS year, COUNT(*) AS total FROM itcp GROUP BY year_graduated ORDER BY year");
if ($chartQuery) {
    while ($row = $chartQuery->fetch_assoc()) {
        $alumniByYear[$row['year']] = $row['total'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Dashboard</title>
    <link rel="stylesheet" href="al_dashboard_css.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="header">
        <img src="olfulogo.png" alt="OLFU Logo">
        <div class="title">
            <h1>OLFU Alumni Portal</h1>
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['user']['firstname'] ?? 'Alumni'); ?></span>
        </div>
        <nav>
            <a href="al_homepage.php">Home</a>
            <a href="al_profile.php">Profile</a>
            <a href="al_logout.php">Logout</a>
        </nav>
    </div>

    <div class="container">
        <div class="sidebar">
            <h3>Dashboard Menu</h3>
            <a href="al_dashboard.php" class="active">
                <i class="material-icons">dashboard</i> Dashboard
            </a>
            <a href="al_directory.php">
                <i class="material-icons">people</i> Alumni Directory
            </a>
            <a href="al_events.php">
                <i class="material-icons">event</i> Events
            </a>
            <a href="al_calendar.php">
                <i class="material-icons">calendar_today</i> Calendar
            </a>
            <a href="al_contact.php">
                <i class="material-icons">contact_support</i> Contact
            </a>
        </div>

        <div class="main-content">
            <h2>Dashboard Overview</h2>
            
            <div class="stats-container">
                <div class="stat-card">
                    <i class="material-icons">people</i>
                    <div class="stat-info">
                        <h3>Total Alumni</h3>
                        <p><?php echo $totalAlumni; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="material-icons">work</i>
                    <div class="stat-info">
                        <h3>Job Listings</h3>
                        <p><?php echo $totalJobs; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="material-icons">event</i>
                    <div class="stat-info">
                        <h3>Upcoming Events</h3>
                        <p><?php echo $totalEvents; ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <i class="material-icons">announcement</i>
                    <div class="stat-info">
                        <h3>Announcements</h3>
                        <p><?php echo $totalAnnouncements; ?></p>
                    </div>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="chart-container">
                    <h3>Alumni Distribution by Graduation Year</h3>
                    <canvas id="alumniChart"></canvas>
                </div>

                <div class="recent-announcements">
                    <h3>Recent Announcements</h3>
                    <?php if (!empty($recentAnnouncements)): ?>
                        <?php foreach ($recentAnnouncements as $announcement): ?>
                            <div class="announcement-card">
                                <h4><?php echo htmlspecialchars($announcement['title']); ?></h4>
                                <p><?php echo htmlspecialchars(substr($announcement['content'], 0, 100)) . '...'; ?></p>
                                <span class="date"><?php echo date('M d, Y', strtotime($announcement['date_posted'])); ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No recent announcements</p>
                    <?php endif; ?>
                </div>

                <div class="upcoming-events">
                    <h3>Upcoming Events</h3>
                    <?php if (!empty($upcomingEvents)): ?>
                        <?php foreach ($upcomingEvents as $event): ?>
                            <div class="event-card">
                                <h4><?php echo htmlspecialchars($event['title']); ?></h4>
                                <p><?php echo htmlspecialchars(substr($event['description'], 0, 100)) . '...'; ?></p>
                                <div class="event-details">
                                    <span><i class="material-icons">event</i> <?php echo date('M d, Y', strtotime($event['date'])); ?></span>
                                    <span><i class="material-icons">location_on</i> <?php echo htmlspecialchars($event['location']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No upcoming events</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize the chart
        const ctx = document.getElementById('alumniChart').getContext('2d');
        const alumniData = <?php echo json_encode($alumniByYear); ?>;
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(alumniData),
                datasets: [{
                    label: 'Number of Alumni',
                    data: Object.values(alumniData),
                    backgroundColor: '#4CAF50',
                    borderColor: '#45a049',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    </script>
</body>
</html>