<?php
$conn = new mysqli("localhost", "root", "", "itcp_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$limit = 20;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$where = "WHERE 
    firstname LIKE '%$search%' OR 
    lastname LIKE '%$search%' OR 
    middlename LIKE '%$search%' OR 
    year_graduated LIKE '%$search%' OR 
    month_graduated LIKE '%$search%'";

$count_sql = "SELECT COUNT(*) AS total FROM itcp $where";
$count_result = $conn->query($count_sql);
$total_rows = $count_result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

$sql = "SELECT * FROM itcp $where ORDER BY lastname ASC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coordinator Alumni Directory</title>
    <link rel="stylesheet" href="ad_alumnidirectory_css.css">
</head>
<body>
<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Coordinator View of Alumni Directory</span>
    </div>
    <nav>
        <a href="co_home.html">Home</a>
        <a href="co_dashboard.php">Dashboard</a>
        <a href="###">Messages</a>
        <a href="###">Notifications</a>
        <a href="co_logout.php">Log Out</a>
    </nav>
</div>

<br><br>
<form class="search-form" method="get">
    <h1>Search Alumni</h1>
    <input type="text" name="search" placeholder="Search by name or graduation year..." value="<?php echo htmlspecialchars($search); ?>">
    <br><br>
    <button type="submit">Search</button>
</form>

<div class="directory">
<?php while ($row = $result->fetch_assoc()): ?>
    <div class="card">
        <img src="uploads/<?php echo htmlspecialchars($row['photo']); ?>" alt="Alumni Photo">

        <fieldset>
            <legend>INFORMATION PROVIDED</legend><br>

            <legend>PERSONAL INFORMATION</legend>
            <p><strong>Name:</strong> <?php echo "{$row['lastname']}, {$row['firstname']} {$row['middlename']} {$row['name_ext']}"; ?></p>
            <p><strong>Birthday:</strong> <?php echo $row['birthday']; ?></p>
            <p><strong>Age:</strong> <?php echo $row['age']; ?></p>
            <p><strong>Gender:</strong> <?php echo $row['gender']; ?></p>
            <p><strong>Civil Status:</strong> <?php echo $row['civil_status']; ?></p>
            <p><strong>Religion:</strong> <?php echo $row['religion']; ?></p>
            <p><strong>Nationality:</strong> <?php echo $row['nationality']; ?></p>
            <p><strong>Email:</strong> <?php echo $row['email']; ?></p>
            <p><strong>Address:</strong> <?php echo $row['address']; ?></p>
            <p><strong>Contact Number:</strong> <?php echo $row['personal_contact']; ?></p>
            <p><strong>Emergency Contact:</strong> <?php echo $row['emergency_contact']; ?></p><br>

            <legend>ACADEMIC INFORMATION</legend>
            <p><strong>Student Number:</strong> <?php echo $row['student_number']; ?></p>
            <p><strong>Program:</strong> <?php echo $row['program']; ?></p>
            <p><strong>Campus:</strong> <?php echo $row['campus']; ?></p>
            <p><strong>Graduated:</strong> <?php echo "{$row['month_graduated']} {$row['year_graduated']}"; ?></p>
            <p><strong>Post-Graduate Education:</strong> <?php echo $row['post_grad']; ?></p>
            <p><strong>Licensure Exam:</strong> <?php echo $row['licensure_exam']; ?></p>
            <p><strong>Club Involvement:</strong> <?php echo $row['club_involvement']; ?></p><br>

            <legend>EMPLOYMENT INFORMATION</legend>
            <p><strong>Employment Status:</strong> <?php echo $row['employment_status']; ?></p>
            <p><strong>Company:</strong> <?php echo $row['company']; ?></p>
            <p><strong>Industry:</strong> <?php echo $row['industry']; ?></p>
            <p><strong>Position:</strong> <?php echo $row['position']; ?></p>
            <p><strong>Employment History:</strong> <?php echo $row['employment_history']; ?></p>
            <p><strong>Previous Role:</strong> <?php echo $row['previous_role']; ?></p>
            <p><strong>Length of Service:</strong> <?php echo $row['length_of_service']; ?></p><br>

            <p><strong>Consent to Share Info:</strong> <?php echo $row['consent'] == '1' ? 'Yes' : 'No'; ?></p>
        </fieldset>
    </div>
<?php endwhile; ?>
</div>

<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo $page - 1; ?>">&laquo; Prev</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>" class="<?php echo ($i == $page) ? 'active' : ''; ?>">
            <?php echo $i; ?>
        </a>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
        <a href="?search=<?php echo urlencode($search); ?>&page=<?php echo $page + 1; ?>">Next &raquo;</a>
    <?php endif; ?>
</div>

</body>
</html>
