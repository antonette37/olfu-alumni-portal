<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: al_homepage.php");
    exit();
}

$dsn = 'mysql:host=localhost;dbname=itcp_db;charset=utf8mb4';
$dbUser = 'root';
$dbPass = '';

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO itcp (
        fname, mname, lname, bday, email, contact_number, sex, address,
        student_id, program, year_graduated,
        employment_status, company, position, work_history,
        consent
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $success = $stmt->execute([
        $_POST['first_name'], $_POST['middle_name'], $_POST['last_name'], $_POST['birthday'],
        $_POST['email'], $_POST['contact'], $_POST['gender'], $_POST['address'],
        $_POST['student_number'], $_POST['program'], $_POST['year_graduated'],
        $_POST['employment_status'], $_POST['company_name'], $_POST['position'], $_POST['work_history'],
        isset($_POST['consent']) ? 1 : 0
    ]);

    $message = $success ? "✅ Alumni registered successfully." : "❌ Error occurred. Please try again.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register Alumni</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-10">
  <div class="max-w-3xl mx-auto bg-white p-8 shadow-md rounded">
    <h1 class="text-xl font-bold mb-6">Alumni Registration</h1>

    <?php if ($message): ?>
      <p class="mb-4 text-green-600 font-semibold"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>

    <form method="POST" class="grid grid-cols-1 gap-4">

      <!-- Personal Info -->
      <div class="grid sm:grid-cols-3 gap-4">
        <input type="text" name="first_name" placeholder="First Name" required class="input">
        <input type="text" name="middle_name" placeholder="Middle Name" class="input">
        <input type="text" name="last_name" placeholder="Last Name" required class="input">
      </div>

      <div class="grid sm:grid-cols-2 gap-4">
        <input type="date" name="birthday" required class="input">
        <select name="gender" required class="input">
          <option value="">Select Gender</option>
          <option>Male</option>
          <option>Female</option>
          <option>Other</option>
        </select>
      </div>

      <div class="grid sm:grid-cols-2 gap-4">
        <input type="email" name="email" placeholder="Email" required class="input">
        <input type="text" name="contact" placeholder="Contact Number" required class="input">
      </div>

      <input type="text" name="address" placeholder="Address" required class="input">

      <!-- Academic Info -->
      <hr class="my-4">
      <div class="grid sm:grid-cols-3 gap-4">
        <input type="text" name="student_number" placeholder="Student Number" required class="input">
        <input type="text" name="program" placeholder="Program" required class="input">
        <input type="number" name="year_graduated" placeholder="Year Graduated" required class="input">
      </div>

      <!-- Employment Info -->
      <hr class="my-4">
      <select name="employment_status" required class="input">
        <option value="">Select Employment Status</option>
        <option>Employed</option>
        <option>Unemployed</option>
        <option>Graduate School</option>
      </select>

      <div class="grid sm:grid-cols-2 gap-4">
        <input type="text" name="company_name" placeholder="Company Name" class="input">
        <input type="text" name="position" placeholder="Position" class="input">
      </div>

      <textarea name="work_history" placeholder="Work History (Optional)" class="input"></textarea>

      <!-- Consent -->
      <label class="inline-flex items-center">
        <input type="checkbox" name="consent" class="mr-2"> I agree to share my information with the alumni network.
      </label>

      <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Register</button>
    </form>
  </div>

  <style>
    .input {
      padding: 0.5rem;
      border: 1px solid #ccc;
      border-radius: 0.375rem;
      width: 100%;
    }
  </style>
</body>
</html>
