<?php
session_start();

if (!isset($_SESSION['coordinator_logged_in']) || $_SESSION['coordinator_logged_in'] !== true) {
    header('Location: co_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Coordinator Dashboard</title>
  <link rel="stylesheet" href="co_dashboard_css.css">
</head>
<body>

  <div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Coordinator Dashboard</span>
    </div>
    <nav>
      <a href="co_home.html">Home</a>
      <a href="co_dashboard.php">Dashboard</a>
      <a href="#">Messages</a>
      <a href="#">Notifications</a>
      <a href="co_logout.php">Log Out</a>
    </nav>
  </div>

  <div class="container">
    
    <div class="sidebar">
      <h3><strong>COORDINATOR</strong></h3>

      <a href="#">Alumni Accounts Management</a>
      <a href="#">Content Management</a>
      <a href="#">Profile</a>
      <a href="co_calendar.php">Calendar</a>
      <a href="co_alumnirecord.php">Alumni Records</a>
      <a href="co_alumnidirectory.php">Alumni Directory</a>
      <a href="#">Contact Messages</a>
      <a href="#">Requests</a>
      <a href="#">Announcements</a>
    </div>

    <div class="main-content">
      <h2>ANNOUNCEMENTS AND EVENTS</h2>
    </div>

  </div>

</body>
</html>
