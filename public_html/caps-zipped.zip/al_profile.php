<?php
session_start();

$host = 'localhost';
$user = 'root';  
$pass = '';
$db = 'itcp_db';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: al_login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM itcp WHERE id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("SQL error: " . $conn->error);
}

$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "No user data found.";
    exit();
}

$stmt->close();
$conn->close();

function displayField($field) {
    return htmlspecialchars($field ?? 'N/A');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="al_profile_css.css">
</head>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Profile Details</span>
    </div>
    <nav>
        <a href="al_home.php">Home</a>
        <a href="al_dashboard.php">Dashboard</a>
        <a href="###">Messages</a>
        <a href="###">Notifications</a>
        <a href="al_logout.php">Log Out</a>
    </nav>
</div>
<body>
<div class="container">
    <aside class="sidebar">
        <nav class="sidebar-nav">

            <a href="al_profileupdate.php">Update your information</a>
            <a href="al_directory.php">Alumni Directory</a>
            <a href="###">Job Postings</a>
            <a href="al_calendar.php">Calendar</a>
        </nav>
    </aside>

    <main class="main-content">
        <h1>Welcome, <?php echo displayField($user['firstname']); ?>!</h1>

        <?php if (!empty($user['profile_picture'])): ?>
            <img src="uploads/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" class="profile-pic">
        <?php endif; ?>
        <h2>Your Profile Details:</h2>
        <div class="table-responsive">
        <table>
            <tr><th>Field</th><th>Details</th></tr>

            <tr><td>First Name:</td><td><?php echo displayField($user['firstname']); ?></td></tr>
            <tr><td>Last Name:</td><td><?php echo displayField($user['lastname']); ?></td></tr>
            <tr><td>Middle Name:</td><td><?php echo displayField($user['middlename']); ?></td></tr>
            <tr><td>Name Extension:</td><td><?php echo displayField($user['name_ext']); ?></td></tr>
            <tr><td>Birthday:</td><td><?php echo displayField($user['birthday']); ?></td></tr>
            <tr><td>Age:</td><td><?php echo displayField($user['age']); ?></td></tr>
            <tr><td>Gender:</td><td><?php echo displayField($user['gender']); ?></td></tr>
            <tr><td>Civil Status:</td><td><?php echo displayField($user['civil_status']); ?></td></tr>
            <tr><td>Religion:</td><td><?php echo displayField($user['religion']); ?></td></tr>
            <tr><td>Nationality:</td><td><?php echo displayField($user['nationality']); ?></td></tr>
            <tr><td>Email:</td><td><?php echo displayField($user['email']); ?></td></tr>
            <tr><td>Address:</td><td><?php echo displayField($user['address']); ?></td></tr>
            <tr><td>Personal Contact:</td><td><?php echo displayField($user['personal_contact']); ?></td></tr>
            <tr><td>Emergency Contact:</td><td><?php echo displayField($user['emergency_contact']); ?></td></tr>

            <tr><td>Student Number:</td><td><?php echo displayField($user['student_number']); ?></td></tr>
            <tr><td>Program:</td><td><?php echo displayField($user['program']); ?></td></tr>
            <tr><td>Campus:</td><td><?php echo displayField($user['campus']); ?></td></tr>
            <tr><td>Month Graduated:</td><td><?php echo displayField($user['month_graduated']); ?></td></tr>
            <tr><td>Year Graduated:</td><td><?php echo displayField($user['year_graduated']); ?></td></tr>
            <tr><td>Post Graduate Education:</td><td><?php echo displayField($user['post_grad']); ?></td></tr>
            <tr><td>Licensure Exam Taken:</td><td><?php echo displayField($user['licensure_exam']); ?></td></tr>
            <tr><td>Club Involvement:</td><td><?php echo displayField($user['club_involvement']); ?></td></tr>

            <tr><td>Employment Status:</td><td><?php echo displayField($user['employment_status']); ?></td></tr>
            <tr><td>Company:</td><td><?php echo displayField($user['company']); ?></td></tr>
            <tr><td>Industry:</td><td><?php echo displayField($user['industry']); ?></td></tr>
            <tr><td>Position:</td><td><?php echo displayField($user['position']); ?></td></tr>
            <tr><td>Employment History:</td><td><?php echo displayField($user['employment_history']); ?></td></tr>
            <tr><td>Previous Role:</td><td><?php echo displayField($user['previous_role']); ?></td></tr>
            <tr><td>Length of Service:</td><td><?php echo displayField($user['length_of_service']); ?></td></tr>
        </table>
    </main>
</div>
</body>
</html>