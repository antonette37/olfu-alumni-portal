<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FAQs - Alumni Management System</title>
    <link rel="stylesheet" href="gen_faqs_css.css">
    <link rel="stylesheet" href="al_home_css.css">
</head>
<body>

<header class="header">
    <img src="olfulogo.png" alt="OLFU Logo"/>
    <div class="title">
        <h1>Our Lady of Fatima University</h1> <span>FAQs</span>
    </div>
    <nav>
        <a href="al_registration.php">Register</a>
        <a href="al_login.php">Log In</a>
        <a href="al_contact.php">Contact Us</a>
        <a href="gen_faqs.php">Help/FAQs</a> 
    </nav>
</header>

<div class="faq-wrapper">
    <div class="faq-left">
        <h1>Frequently Asked Questions</h1>
        <div class="search-box">
            <input type="text" placeholder="Search question here">
            <button><span>&#128269;</span></button>
        </div>

        <div class="faq-sections">
            <?php
            $faq_sections = [
                "General FAQs" => [
                    ["What is the Alumni Management System?",
                     "The Alumni Management System is a platform that allows former students to register, connect, and engage with the institution and fellow alumni."],
                    ["Who can register on the system?",
                     "All graduates of [Your Institution Name] can register, provided they verify their credentials."],
                    ["How do I create an alumni account?",
                     "Click on the 'Register' button, fill in your details, and submit. An admin will verify and approve your registration."],
                    ["I forgot my password. How do I reset it?",
                     "Click on 'Forgot Password' and follow the steps to reset it via email."],
                    ["Can I update my profile after registration?",
                     "Yes, once logged in, go to your profile section and edit your details."]
                ],
                "Features and Functionalities" => [
                    ["What features are available for registered alumni?",
                     "You can update your profile, search for other alumni, view jobs, join events, and more."],
                    ["How do I search for other alumni?",
                     "Use the 'Directory' page to search by name, year, program, or company."],
                    ["What is the purpose of the job portal section?",
                     "The job portal helps alumni find and share job opportunities."],
                    ["Can I post a job opportunity for other alumni?",
                     "Yes, go to 'Jobs' and click 'Post a Job' while logged in."],
                    ["How do I participate in alumni events?",
                     "Check the 'Calendar' for upcoming events and click 'RSVP'."]
                ],
                "Privacy and Data Handling" => [
                    ["Is my personal information secure?",
                     "Yes, your data is encrypted and securely stored."],
                    ["Can I control what information is visible to others?",
                     "Yes, manage your privacy settings in your profile."],
                    ["What happens if I don’t consent to share my data?",
                     "Some features like directory listing may be limited."]
                ],
                "Admin Related" => [
                    ["How do I become an admin of the system?",
                     "Admin access is provided by the system administrator."],
                    ["What can an admin do in the system?",
                     "Admins manage alumni data, approve accounts, and handle job/event posts."],
                    ["Can admins edit or delete alumni profiles?",
                     "Yes, if they have the proper permissions."],
                    ["Can I download alumni data as an Excel file?",
                     "Yes, admins can export alumni data to Excel."]
                ],
                "Technical Support" => [
                    ["Which file formats can I upload for resume or photo?",
                     "PDF, DOCX, JPG, and PNG formats are supported."],
                    ["Why is my registration still pending?",
                     "It’s under admin review and may take up to 48 hours."],
                    ["Who do I contact for technical support?",
                     "Use the 'Contact Us' page or email support at support@email.com."]
                ]
            ];

            foreach ($faq_sections as $section_title => $faqs){
                echo "<fieldset class='faq-section'>";
                echo "<legend>$section_title</legend>";

                foreach ($faqs as $faq) {
                    echo "<div class='faq-item'>";
                    echo "<div class='faq-question'>{$faq[0]} <span class='toggle-icon'>+</span></div>";
                    echo "<div class='faq-answer'>{$faq[1]}</div>";
                    echo "</div>";
                }

                echo "</fieldset>";
            }
            ?>
        </div>
    </div>

    <div class="faq-right">
        <img src="###" alt="AMS FAQs Illustration">
    </div>
</div>

<script>
    document.querySelectorAll('.faq-question').forEach(q => {
        q.addEventListener('click', () => {
            const parent = q.parentElement;
            parent.classList.toggle('open');
            const icon = q.querySelector('.toggle-icon');
            icon.textContent = icon.textContent === '+' ? '−' : '+';
        });
    });
</script>
</body>
</html>
