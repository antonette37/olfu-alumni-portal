<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Calendar | OLFU</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  />
  <style>
    /* Scrollbar for right panel */
    .scrollbar-thin::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    .scrollbar-thin::-webkit-scrollbar-track {
      background: transparent;
    }
    .scrollbar-thin::-webkit-scrollbar-thumb {
      background-color: #a0aec0;
      border-radius: 3px;
    }
    /* Scrollbar for horizontal scroll */
    .scrollbar-x::-webkit-scrollbar {
      height: 6px;
    }
    .scrollbar-x::-webkit-scrollbar-track {
      background: transparent;
    }
    .scrollbar-x::-webkit-scrollbar-thumb {
      background-color: #a0aec0;
      border-radius: 3px;
    }
  </style>
</head>
<body class="bg-gray-100">
  <!-- HEADER -->
  <header class="bg-white shadow-md fixed top-0 left-0 right-0 z-50 border-t-4 border-green-900">
    <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
      <div class="flex items-center space-x-3">
        <!-- Logo with link to al_homepage.php -->
        <a href="al_homepage.php">
          <img src="olfulogo.png" alt="Fatima Logo" class="h-10 w-10" />
        </a>
        <div>
          <h1 class="text-xl font-bold text-gray-800">Fatima Alumni</h1>
          <p class="text-sm text-gray-600">Our Lady of Fatima University</p>
        </div>
      </div>
      <nav class="flex items-center space-x-6 text-gray-700 font-medium">
        <a href="al_directory.php" class="hover:text-green-700">Find Alumni</a>
        <a href="al_events.php" class="hover:text-green-700">Events</a>
        <a href="al_careers.php" class="hover:text-green-700">Careers</a>
        <a href="al_dashboard.php" class="hover:text-green-700">Dashboard</a>
        <a href="jobs.php" class="hover:text-green-700">Jobs</a>
        <a href="about.php" class="hover:text-green-700">About</a>
        <a
          href="logout.php"
          class="bg-green-700 text-white px-4 py-1.5 rounded-md hover:bg-green-800 font-semibold"
          >Logout</a
        >
      </nav>
    </div>
  </header>

   <!-- SIDEBAR -->
  <aside
    id="sidebar"
    class="bg-green-700 text-white w-16 hover:w-64 transition-all duration-300 fixed h-full z-40 overflow-hidden pt-20 group"
  >
    <!-- Hamburger remains visible -->
    <div class="flex items-center justify-center h-16">
      <i class="fas fa-bars text-2xl"></i>
    </div>
    <ul class="space-y-4 mt-6 pl-4 pr-4">
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_profile.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-user mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Profile</p>
            <p class="text-sm text-green-200">View and edit alumni profile</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_events.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-calendar mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Events</p>
            <p class="text-sm text-green-200">Upcoming alumni events</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_announcements.php"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-bullhorn mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Announcements</p>
            <p class="text-sm text-green-200">Recent news & updates</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_jobs.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-briefcase mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Job Board</p>
            <p class="text-sm text-green-200">Opportunities for alumni</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_calendar.php#calendar"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-calendar-alt mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Calendar</p>
            <p class="text-sm text-green-200">Event calendar overview</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_directory.php#directory"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-address-book mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Directory</p>
            <p class="text-sm text-green-200">Connect with other alumni</p>
          </div>
        </a>
      </li>
    </ul>
  </aside>

  <main class="pt-20 pl-16 md:pl-64">
    <div class="max-w-[1400px] mx-auto p-4 min-h-screen bg-white rounded-md shadow-md">
      <div class="flex flex-col md:flex-row gap-6">
        <!-- Left main calendar area -->
        <div class="flex-1 flex flex-col min-w-0">
          <!-- Top controls -->
          <div
            class="flex items-center justify-between mb-4 flex-wrap gap-2 max-w-full"
          >
            <div class="flex items-center space-x-2 flex-shrink-0">
              <button
                class="text-xs text-gray-700 bg-gray-200 rounded px-3 py-1 hover:bg-gray-300"
                type="button"
              >
                Today
              </button>
              <button
                class="text-gray-500 hover:text-gray-700 text-sm px-2 py-1 rounded"
                type="button"
                aria-label="Previous"
              >
                <i class="fas fa-arrow-left"></i>
              </button>
              <button
                class="text-gray-500 hover:text-gray-700 text-sm px-2 py-1 rounded"
                type="button"
                aria-label="Next"
              >
                <i class="fas fa-arrow-right"></i>
              </button>
              <span class="text-sm text-gray-700 select-none whitespace-nowrap"
                >May 2025</span
              >
            </div>
            <div
              class="flex items-center space-x-2 flex-shrink-0 overflow-x-auto scrollbar-x no-scrollbar"
            >
              <button
                class="text-xs text-gray-700 bg-gray-100 rounded px-3 py-1 hover:bg-gray-200 whitespace-nowrap"
                type="button"
              >
                Week
              </button>
              <button
                class="text-xs text-white bg-gray-600 rounded px-3 py-1 cursor-default whitespace-nowrap"
                type="button"
                aria-current="true"
              >
                Month
              </button>
              <button
                class="text-xs text-gray-700 bg-gray-100 rounded px-3 py-1 hover:bg-gray-200 whitespace-nowrap"
                type="button"
              >
                Agenda
              </button>
              <button
                class="text-xs text-gray-700 bg-gray-100 rounded px-3 py-1 hover:bg-gray-200 whitespace-nowrap"
                type="button"
                aria-label="Add"
              >
                +
              </button>
            </div>
          </div>

          <!-- Weekday headers -->
          <div
            class="grid grid-cols-7 border-t border-b border-gray-200 text-xs text-gray-600 select-none min-w-[600px]"
          >
            <div class="py-2 text-center font-semibold">SUN</div>
            <div class="py-2 text-center font-semibold">MON</div>
            <div class="py-2 text-center font-semibold">TUE</div>
            <div class="py-2 text-center font-semibold">WED</div>
            <div class="py-2 text-center font-semibold">THU</div>
            <div class="py-2 text-center font-semibold">FRI</div>
            <div class="py-2 text-center font-semibold">SAT</div>
          </div>

          <!-- Calendar grid -->
          <div
            class="grid grid-cols-7 border-b border-gray-200 text-xs text-gray-700 flex-1 min-h-[600px] min-w-[600px] overflow-y-auto scrollbar-thin"
          >
            <!-- Each day cell -->
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              27
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              28
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              29
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              30
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              1
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              2
            </div>
            <div
              class="border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              3
            </div>

            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              4
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              5
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              6
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              7
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              8
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              9
            </div>
            <div
              class="border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              10
            </div>

            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              11
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              12
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-200 select-none"
            >
              13
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              14
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              15
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              16
            </div>
            <div
              class="border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] bg-gray-100 select-none"
            >
              17
            </div>

            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              18
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              19
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              20
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              21
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              22
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              23
            </div>
            <div
              class="border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              24
            </div>

            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              25
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              26
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              27
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              28
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              29
            </div>
            <div
              class="border-r border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              30
            </div>
            <div
              class="border-b border-gray-200 min-h-[80px] p-1 text-right text-[11px] text-gray-400 select-none"
            >
              31
            </div>
          </div>
        </div>

        <!-- Right sidebar -->
        <div
          class="w-full md:w-[320px] mt-6 md:mt-0 md:ml-6 flex flex-col text-xs text-gray-700 select-none min-w-[280px]"
        >
          <div class="border border-gray-200 rounded shadow-sm p-3">
            <div class="flex items-center justify-between mb-2">
              <button
                class="text-gray-500 hover:text-gray-700 p-1 rounded"
                aria-label="Previous month"
                type="button"
              >
                <i class="fas fa-chevron-left"></i>
              </button>
              <div class="font-semibold text-center flex-1">May 2025</div>
              <button
                class="text-gray-500 hover:text-gray-700 p-1 rounded"
                aria-label="Next month"
                type="button"
              >
                <i class="fas fa-chevron-right"></i>
              </button>
            </div>
            <div
              class="grid grid-cols-7 gap-0.5 text-center text-[10px] text-gray-500 mb-1 select-none"
            >
              <div>Su</div>
              <div>Mo</div>
              <div>Tu</div>
              <div>We</div>
              <div>Th</div>
              <div>Fr</div>
              <div>Sa</div>
            </div>
            <div
              class="grid grid-cols-7 gap-0.5 text-center text-[11px] text-gray-700"
            >
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">27</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">28</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">29</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">30</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">1</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">2</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">3</div>

              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">4</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">5</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">6</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">7</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">8</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">9</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">10</div>

              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">11</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">12</div>
              <div class="py-0.5 rounded bg-gray-200 cursor-default font-semibold">
                13
              </div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">14</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">15</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">16</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">17</div>

              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">18</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">19</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">20</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">21</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">22</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">23</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">24</div>

              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">25</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">26</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">27</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">28</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">29</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">30</div>
              <div class="py-0.5 rounded hover:bg-gray-100 cursor-pointer">31</div>
            </div>
          </div>

          <div class="mt-4 border-b border-gray-200 pb-2">
            <div
              class="flex items-center justify-between cursor-pointer select-none"
            >
              <div
                class="font-semibold text-[11px] text-gray-700 flex items-center space-x-1"
              >
                <i class="fas fa-chevron-down text-[10px]"></i>
                <span>CALENDARS</span>
              </div>
            </div>
            <div class="mt-2 max-h-[120px] overflow-y-auto scrollbar-thin pr-1">
              <label
                class="flex items-start space-x-2 text-[11px] leading-tight cursor-pointer"
              >
                <input type="checkbox" checked class="mt-1" />
                <span class="flex-1">
                  <span class="block text-blue-600 font-semibold"
                    >MA. ANTONETTE CABANG</span
                  >
                </span>
                <button
                  class="text-gray-400 hover:text-gray-600 p-1"
                  aria-label="Options"
                >
                  <i class="fas fa-ellipsis-v text-xs"></i>
                </button>
              </label>
              <label
                class="flex items-start space-x-2 text-[11px] leading-tight cursor-pointer mt-1"
              >
                <input type="checkbox" class="mt-1" />
                <span class="flex-1">
                  <span class="block font-semibold"
                    >BUSINESS APPLICATION MANAGEMENT - BSIT 3-Y2-3</span
                  >
                </span>
                <button
                  class="text-gray-400 hover:text-gray-600 p-1"
                  aria-label="Options"
                >
                  <i class="fas fa-ellipsis-v text-xs"></i>
                </button>
              </label>
              <label
                class="flex items-start space-x-2 text-[11px] leading-tight cursor-pointer mt-1"
              >
                <input type="checkbox" class="mt-1" />
                <span class="flex-1">
                  <span class="block font-semibold"
                    >HUMAN COMPUTER INTERACTION II - BSIT 3-Y2-3</span
                  >
                </span>
                <button
                  class="text-gray-400 hover:text-gray-600 p-1"
                  aria-label="Options"
                >
                  <i class="fas fa-ellipsis-v text-xs"></i>
                </button>
              </label>
              <label
                class="flex items-start space-x-2 text-[11px] leading-tight cursor-pointer mt-1"
              >
                <input type="checkbox" class="mt-1" />
                <span class="flex-1">
                  <span class="block font-semibold"
                    >INFORMATION ASSURANCE AND SECURITY II W/ LAB - BSIT 3-Y2-3</span
                  >
                </span>
                <button
                  class="text-gray-400 hover:text-gray-600 p-1"
                  aria-label="Options"
                >
                  <i class="fas fa-ellipsis-v text-xs"></i>
                </button>
              </label>
              <label
                class="flex items-start space-x-2 text-[11px] leading-tight cursor-pointer mt-1"
              >
                <input type="checkbox" class="mt-1" />
                <span class="flex-1">
                  <span class="block font-semibold">INTEGRATED PROGRAMMING</span>
                </span>
                <button
                  class="text-gray-400 hover:text-gray-600 p-1"
                  aria-label="Options"
                >
                  <i class="fas fa-ellipsis-v text-xs"></i>
                </button>
              </label>
            </div>
          </div>

          <div class="mt-4 border-b border-gray-200 pb-2">
            <div
              class="flex items-center justify-between cursor-pointer select-none"
            >
              <div
                class="font-semibold text-[11px] text-gray-700 flex items-center space-x-1"
              >
                <i class="fas fa-chevron-down text-[10px]"></i>
                <span>UNDATED</span>
              </div>
            </div>
          </div>

          <div
            class="mt-4 flex items-center space-x-2 text-[11px] text-green-700 cursor-pointer select-none"
          >
            <i class="fas fa-calendar-alt text-[14px]"></i>
            <span>Calendar Feed</span>
          </div>
        </div>
      </div>
    </div>
  </main>
</body>
</html>