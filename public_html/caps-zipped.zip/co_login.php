<?php
session_start();

$coordinator_username = "coordinator"; /* default */
$coordinator_password = "password1"; /* default */

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === $coordinator_username && $password === $coordinator_password) {
        $_SESSION['coordinator_logged_in'] = true;
        header("Location: co_dashboard.php");
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Coordinator Login</title>
    <link rel="stylesheet" href="co_login_css.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Coordinator Log In</span>
    </div>
    <nav>
        <a href="co_home.html">Home</a>
        <a href="#">User Log In</a>
        <a href="#">Forgot Password</a>
        <a href="gen_faqs.php">Help</a>
        <a href="gen_dashboard.php">Alumni Dashboard</a>
    </nav>
</div>

<?php
if (!empty($error_message)) {
    echo "<center><div style='color:red; font-weight:bold;'>$error_message</div></center><br>";
}
?>

<center>
    <form action="" method="POST">
        <fieldset>
            <legend><h3>Login with Username and Password</h3></legend>

            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required><br><br>

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required><br><br>

            <button type="submit">Login</button>
        </fieldset>
    </form>

    <fieldset>
        <div class="signup-link">
            <p>Don't have a coordinator account? <a href="#">Contact Shaira!</a></p>
        </div>
    </fieldset>
</center>

</body>
</html>
