<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <title>Fatima Alumni</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
    rel="stylesheet"
  />
  <style>
    /* Custom scrollbar for the page */
    body::-webkit-scrollbar {
      width: 8px;
    }
    body::-webkit-scrollbar-thumb {
      background-color: #8b0a1c;
      border-radius: 4px;
    }
  </style>
</head>
<body class="bg-white text-gray-900 font-sans">

  <!-- HEADER -->
  <header class="bg-white shadow-md fixed top-0 left-0 right-0 z-50 border-t-4 border-green-900">
    <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
      <div class="flex items-center space-x-3">
        <!-- Logo with a link to al_homepage.php -->
        <a href="al_homepage.php">
          <img src="olfulogo.png" alt="Fatima Logo" class="h-10 w-10 sm:h-12 sm:w-12" />
        </a>
        <div>
          <h1 class="text-xl font-bold text-gray-800">Fatima Alumni</h1>
          <p class="text-sm text-gray-600">Our Lady of Fatima University</p>
        </div>
      </div>
      <nav class="flex items-center space-x-6 text-gray-700 font-medium">
        <a href="al_directory.php" class="hover:text-green-700">Find Alumni</a>
        <a href="al_events.php" class="hover:text-green-700">Events</a>
        <a href="careers.php" class="hover:text-green-700">Careers</a>
        <a href="al_dashboard.php" class="text-green-800 font-semibold">Dashboard</a>
        <a href="jobs.php" class="hover:text-green-700">Jobs</a>
        <a href="about.php" class="hover:text-green-700">About</a>
        <a href="logout.php" class="bg-green-700 text-white px-4 py-1.5 rounded-md hover:bg-green-800 font-semibold">Logout</a>
      </nav>
    </div>
  </header>

   <!-- SIDEBAR -->
  <aside
    id="sidebar"
    class="bg-green-700 text-white w-16 hover:w-64 transition-all duration-300 fixed h-full z-40 overflow-hidden pt-20 group"
  >
    <!-- Hamburger remains visible -->
    <div class="flex items-center justify-center h-16">
      <i class="fas fa-bars text-2xl"></i>
    </div>
    <ul class="space-y-4 mt-6 pl-4 pr-4">
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_profile.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-user mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Profile</p>
            <p class="text-sm text-green-200">View and edit alumni profile</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_events.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-calendar mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Events</p>
            <p class="text-sm text-green-200">Upcoming alumni events</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="announcements.php#announcements"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-bullhorn mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Announcements</p>
            <p class="text-sm text-green-200">Recent news & updates</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_jobs.php#jobs" class="flex items-center space-x-4 w-full">
          <i class="fas fa-briefcase mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Job Board</p>
            <p class="text-sm text-green-200">Opportunities for alumni</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_calendar.php#calendar"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-calendar-alt mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Calendar</p>
            <p class="text-sm text-green-200">Event calendar overview</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_directory.php#directory"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-address-book mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Directory</p>
            <p class="text-sm text-green-200">Connect with other alumni</p>
          </div>
        </a>
      </li>
    </ul>
  </aside>

  <!-- MAIN CONTENT -->
  <main class="ml-16 pt-28 px-4 sm:px-6 md:px-10 max-w-7xl mx-auto">
    <div class="flex flex-col lg:flex-row">
      <!-- Left Filters -->
      <aside
        class="w-full lg:w-48 flex-shrink-0 pr-0 lg:pr-6 mb-6 lg:mb-0"
        aria-label="Filters"
      >
        <div class="text-xs text-gray-700 mb-2">Filters.</div>
        <form method="GET" action="" class="space-y-2" id="filterForm">
          <div class="flex">
            <input
              id="keyword"
              name="keyword"
              class="border border-gray-300 text-xs px-2 py-1 w-full focus:outline-none focus:ring-1 focus:ring-[#8b0a1c]"
              placeholder="Enter keyword..."
              type="text"
              value="<?= htmlspecialchars($_GET['keyword'] ?? '') ?>"
            />
            <button
              aria-label="Search"
              class="text-green-700 px-3 ml-1 flex items-center justify-center"
              type="submit"
            >
              <i class="fas fa-search text-green-700 text-xs"></i>
            </button>
          </div>
          <select
            name="filter"
            id="filter"
            class="w-full bg-gray-300 text-gray-900 text-xs font-semibold py-1 px-2"
          >
            <option value="">Select Filter</option>
            <option value="role" <?= (($_GET['filter'] ?? '') === 'role') ? 'selected' : '' ?>>Search by Role</option>
            <option value="year_admission" <?= (($_GET['filter'] ?? '') === 'year_admission') ? 'selected' : '' ?>>Year of Admission</option>
            <option value="year_graduation" <?= (($_GET['filter'] ?? '') === 'year_graduation') ? 'selected' : '' ?>>Year of Graduation</option>
            <option value="course_degree" <?= (($_GET['filter'] ?? '') === 'course_degree') ? 'selected' : '' ?>>Course/Degree</option>
            <option value="house" <?= (($_GET['filter'] ?? '') === 'house') ? 'selected' : '' ?>>House</option>
            <option value="current_city" <?= (($_GET['filter'] ?? '') === 'current_city') ? 'selected' : '' ?>>Current City</option>
            <option value="company" <?= (($_GET['filter'] ?? '') === 'company') ? 'selected' : '' ?>>Company</option>
            <option value="designation" <?= (($_GET['filter'] ?? '') === 'designation') ? 'selected' : '' ?>>Designation</option>
            <option value="work_industry" <?= (($_GET['filter'] ?? '') === 'work_industry') ? 'selected' : '' ?>>Work Industry</option>
            <option value="other_institute" <?= (($_GET['filter'] ?? '') === 'other_institute') ? 'selected' : '' ?>>Other Institute</option>
            <option value="other_degree" <?= (($_GET['filter'] ?? '') === 'other_degree') ? 'selected' : '' ?>>Other Degree</option>
            <option value="other_department" <?= (($_GET['filter'] ?? '') === 'other_department') ? 'selected' : '' ?>>Other Department</option>
          </select>
        </form>
      </aside>

      <!-- Right Content -->
      <section class="flex-1">
        <?php
          // Connect to database to get total members count and filtered profiles
          $host = '127.0.0.1';
          $db = 'itcp_db';
          $user = 'root'; // Change if needed
          $pass = ''; // Change if needed
          $charset = 'utf8mb4';

          $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
          $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
          ];

          $totalMembers = 0;
          $profiles = [];
          try {
            $pdo = new PDO($dsn, $user, $pass, $options);

            // Count total members with consent
            $countStmt = $pdo->query("SELECT COUNT(*) AS total FROM itcp WHERE consent = 1");
            $totalMembers = $countStmt->fetchColumn() ?: 0;

            // Prepare filtering
            $keyword = trim($_GET['keyword'] ?? '');
            $filter = $_GET['filter'] ?? '';

            $allowedFilters = [
              'role' => 'previous_role',
              'year_admission' => 'year_graduated', // Assuming year_admission not in DB, using year_graduated as fallback
              'year_graduation' => 'year_graduated',
              'course_degree' => 'program',
              'house' => 'campus', // Assuming house maps to campus
              'current_city' => 'address',
              'company' => 'company',
              'designation' => 'position',
              'work_industry' => 'industry',
              'other_institute' => 'club_involvement', // Approximate mapping
              'other_degree' => 'post_grad', // Approximate mapping
              'other_department' => 'program' // Approximate mapping
            ];

            $whereClauses = ["consent = 1"];
            $params = [];

            if ($keyword !== '' && isset($allowedFilters[$filter])) {
              $column = $allowedFilters[$filter];
              $whereClauses[] = "$column LIKE :keyword";
              $params[':keyword'] = "%$keyword%";
            } elseif ($keyword !== '') {
              // If filter not selected or invalid, search multiple columns
              $searchCols = ['firstname', 'lastname', 'program', 'company', 'position', 'address'];
              $likeClauses = [];
              foreach ($searchCols as $col) {
                $likeClauses[] = "$col LIKE :keyword";
              }
              $whereClauses[] = '(' . implode(' OR ', $likeClauses) . ')';
              $params[':keyword'] = "%$keyword%";
            }

            $whereSQL = implode(' AND ', $whereClauses);
            $sql = "SELECT * FROM itcp WHERE $whereSQL ORDER BY lastname, firstname LIMIT 2711";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $profiles = $stmt->fetchAll();

          } catch (PDOException $e) {
            $totalMembers = 0;
            $profiles = [];
          }
        ?>
        <div
          class="bg-green-700 text-white text-xs font-semibold px-3 py-1 mb-3 select-none rounded"
        >
          <?= htmlspecialchars($totalMembers) ?> Members in community
        </div>
        <div class="text-xs font-normal mb-2 select-none">All Profiles</div>
        <div
          id="profilesGrid"
          class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4"
        >
          <?php
          if (count($profiles) === 0) {
            echo '<div class="text-gray-600 text-sm col-span-full">No profiles found.</div>';
          } else {
            foreach ($profiles as $row) {
              $fullName = htmlspecialchars($row['firstname'] . ' ' . $row['middlename'] . ' ' . $row['lastname'] . ($row['name_ext'] ? ' ' . $row['name_ext'] : ''));
              $photoPath = htmlspecialchars($row['photo']);
              $photoUrl = $photoPath && file_exists(__DIR__ . '/photos/' . $photoPath)
                ? 'photos/' . $photoPath
                : 'https://placehold.co/150x180?text=No+Image';
              $yearGrad = htmlspecialchars($row['year_graduated']);
              $program = htmlspecialchars($row['program']);
              $city = htmlspecialchars(explode(',', $row['address'])[0]);
              echo '<div class="border border-gray-300 p-2">';
              echo '<img src="' . $photoUrl . '" alt="Portrait of ' . $fullName . '" class="w-full h-[180px] object-cover mb-1" width="150" height="180" />';
              echo '<div class="text-[10px] font-semibold leading-tight mb-0.5">' . $fullName . '</div>';
              echo '<div class="text-[8px] leading-tight text-gray-600">';
              echo 'Class of ' . $yearGrad . '<br />';
              echo $program . '<br />';
              echo $city;
              echo '</div>';
              echo '</div>';
            }
          }
          ?>
        </div>
      </section>
    </div>
  </main>
</body>
</html>