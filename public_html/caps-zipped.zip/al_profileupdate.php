<?php
session_start();
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "itcp_db"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: al_homepage.php");
    exit;
}

$user_id = $_SESSION['user_id']; 

$sql = "SELECT * FROM itcp WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $middlename = $_POST['middlename'];
    $name_ext = $_POST['name_ext'];
    $birthday = $_POST['birthday'];
    $civil_status = $_POST['civil_status'];
    $religion = $_POST['religion'];
    $nationality = $_POST['nationality'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $personal_contact = $_POST['personal_contact'];
    $emergency_contact = $_POST['emergency_contact'];
    $student_number = $_POST['student_number'];
    $program = $_POST['program'];
    $campus = $_POST['campus'];
    $month_graduated = $_POST['month_graduated'];
    $year_graduated = $_POST['year_graduated'];
    $post_grad = $_POST['post_grad'];
    $licensure_exam = $_POST['licensure_exam'];
    $club_involvement = $_POST['club_involvement'];
    $employment_status = $_POST['employment_status'];
    $company = $_POST['company'];
    $industry = $_POST['industry'];
    $position = $_POST['position'];
    $employment_history = $_POST['employment_history'];
    $previous_role = $_POST['previous_role'];
    $length_of_service = $_POST['length_of_service'];

    $sql_update = "UPDATE itcp SET 
        firstname = ?, lastname = ?, middlename = ?, name_ext = ?, birthday = ?, gender = ?, 
        civil_status = ?, religion = ?, nationality = ?, email = ?, address = ?, personal_contact = ?, 
        emergency_contact = ?, student_number = ?, program = ?, campus = ?, month_graduated = ?, 
        year_graduated = ?, post_grad = ?, licensure_exam = ?, club_involvement = ?, employment_status = ?, 
        company = ?, industry = ?, position = ?, employment_history = ?, previous_role = ?, 
        length_of_service = ? WHERE id = ?";

    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssssssssssssssssssssssssssssi", 
        $firstname, $lastname, $middlename, $name_ext, $birthday, $gender, $civil_status, $religion, 
        $nationality, $email, $address, $personal_contact, $emergency_contact, $student_number, 
        $program, $campus, $month_graduated, $year_graduated, $post_grad, $licensure_exam, $club_involvement, 
        $employment_status, $company, $industry, $position, $employment_history, $previous_role, 
        $length_of_service, $user_id);

    if ($stmt_update->execute()) {
        echo "Profile updated successfully!";
    } else {
        echo "Error updating profile: " . $stmt_update->error;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Profile</title>
    <link rel="stylesheet" href="al_profileupdate_css.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Update Profile</span>
    </div>
    <nav>
        <a href="al_home.html">Home</a>
        <a href="al_dashboard.php">Dashboard</a>
        <a href="al_contact.php">Contact Us</a>
        <a href="gen_faqs.php">Help/FAQS</a>
    </nav>
</div>

    <div class="container">
        <h1>Update Your Profile</h1>
        <form method="POST" action="">

            <!-- Personal Information -->
            <fieldset>
                <legend><h3>Personal Information</h3></legend>
                <tr>
                    <td><label for="firstname">First Name:</label></td>
                    <td><input type="text" name="firstname" value="<?php echo $user['firstname']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="lastname">Last Name:</label></td>
                    <td><input type="text" name="lastname" value="<?php echo $user['lastname']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="middlename">Middle Name:</label></td>
                    <td><input type="text" name="middlename" value="<?php echo $user['middlename']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="name_ext">Name Extension (if any):</label></td>
                    <td><input type="text" name="name_ext" value="<?php echo $user['name_ext']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="birthday">Birthday:</label></td>
                    <td><input type="date" name="birthday" value="<?php echo $user['birthday']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label>Gender:</label></td>
                    <td>
                        <input type="radio" name="gender" value="male" <?php echo ($user['gender'] == 'male' ? 'checked' : ''); ?>> Male
                        <input type="radio" name="gender" value="female" <?php echo ($user['gender'] == 'female' ? 'checked' : ''); ?>> Female
                    </td>
                </tr><br><br>
                <tr>
                    <td><label for="civil_status">Civil Status:</label></td>
                    <td><input type="text" name="civil_status" value="<?php echo $user['civil_status']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="religion">Religion:</label></td>
                    <td><input type="text" name="religion" value="<?php echo $user['religion']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="nationality">Nationality:</label></td>
                    <td><input type="text" name="nationality" value="<?php echo $user['nationality']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="email">Email Address:</label></td>
                    <td><input type="email" name="email" value="<?php echo $user['email']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="address">Address:</label></td>
                    <td><input type="text" name="address" value="<?php echo $user['address']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="personal_contact">Personal Contact Number:</label></td>
                    <td><input type="text" name="personal_contact" value="<?php echo $user['personal_contact']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="emergency_contact">Emergency Contact Number:</label></td>
                    <td><input type="text" name="emergency_contact" value="<?php echo $user['emergency_contact']; ?>"></td>
                </tr><br>
            </fieldset>

            <!-- Academic Information -->
            <fieldset>
                     <legend><h3>Academic Information</h3></legend>
                <tr>
                    <td><label for="student_number">Student Number:</label></td>
                    <td><input type="text" name="student_number" value="<?php echo $user['student_number']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="program">Program:</label></td>
                    <td><input type="text" name="program" value="<?php echo $user['program']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="campus">Campus:</label></td>
                    <td><input type="text" name="campus" value="<?php echo $user['campus']; ?>" required></td>
                </tr><br><br>
                <tr>
                    <td><label for="month_graduated">Month Graduated:</label></td>
                    <td><input type="text" name="month_graduated" value="<?php echo $user['month_graduated']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="year_graduated">Year Graduated:</label></td>
                    <td><input type="text" name="year_graduated" value="<?php echo $user['year_graduated']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="post_grad">Post Graduate Education:</label></td>
                    <td><input type="text" name="post_grad" value="<?php echo $user['post_grad']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="licensure_exam">Licensure Exam Taken:</label></td>
                    <td><input type="text" name="licensure_exam" value="<?php echo $user['licensure_exam']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="club_involvement">Club Involvement:</label></td>
                    <td><input type="text" name="club_involvement" value="<?php echo $user['club_involvement']; ?>"></td>
                </tr><br>
            </fieldset>

            <!-- Employment Information -->
            <fieldset>
                <legend><h3>Employment Information</h3></legend>
                <tr>
                    <td><label for="employment_status">Employment Status:</label></td>
                    <td><input type="text" name="employment_status" value="<?php echo $user['employment_status']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="company">Company:</label></td>
                    <td><input type="text" name="company" value="<?php echo $user['company']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="industry">Industry:</label></td>
                    <td><input type="text" name="industry" value="<?php echo $user['industry']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="position">Position:</label></td>
                    <td><input type="text" name="position" value="<?php echo $user['position']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="employment_history">Employment History:</label></td>
                    <td><input type="text" name="employment_history" value="<?php echo $user['employment_history']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="previous_role">Previous Role:</label></td>
                    <td><input type="text" name="previous_role" value="<?php echo $user['previous_role']; ?>"></td>
                </tr><br><br>
                <tr>
                    <td><label for="length_of_service">Length of Service:</label></td>
                    <td><input type="text" name="length_of_service" value="<?php echo $user['length_of_service']; ?>"></td>
                </tr><br><br><br>
            </table>

            <button type="submit">Save Updated Profile</button>
        </form>
    </div>
</body>
</html>
