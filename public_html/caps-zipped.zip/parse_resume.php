<?php
header('Content-Type: application/json');

// Affinda API Configuration
define('AFFINDA_API_KEY', 'YOUR_API_KEY_HERE'); // Replace with your actual API key

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['resume'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
    exit;
}

$resumeFile = $_FILES['resume'];
if ($resumeFile['error'] !== UPLOAD_ERR_OK) {
    echo json_encode([
        'success' => false,
        'message' => 'Error uploading file'
    ]);
    exit;
}

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, 'https://api.affinda.com/v2/resumes');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . AFFINDA_API_KEY,
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, [
    'file' => new CURLFile($resumeFile['tmp_name'], $resumeFile['type'], $resumeFile['name']),
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);
    echo json_encode([
        'success' => true,
        'data' => $data['data']
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Error parsing resume: ' . $response
    ]);
}
?>