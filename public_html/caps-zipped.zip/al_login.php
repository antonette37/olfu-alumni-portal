<?php
session_start();

$host = 'localhost';
$db = 'itcp_db';
$user = 'root';
$pass = '';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $stmt = $conn->prepare("SELECT * FROM itcp WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user'] = $user;
                header("Location: al_dashboard.php");
                exit;
            } else {
                $msg = "Invalid email or password.";
            }
        } else {
            $msg = "Invalid email or password.";
        }
    } else {
        $msg = "Please enter email and password.";
    }
}
?>

<!-- HTML form remains the same -->


<!DOCTYPE html>
<html>
<head>
    <title>Alumni Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php if (!empty($msg)) echo "<p style='color:red;'>$msg</p>"; ?>
    <form method="post" action="al_login.php">
        <label>Email:</label><br>
        <input type="email" name="email" required><br>
        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
