<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'itcp_db';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Upload photo
    $photo = $_FILES['photo']['name'] ?? '';
    $photo_tmp = $_FILES['photo']['tmp_name'] ?? '';
    $photo_path = 'photos/' . basename($photo);
    if (!empty($photo)) {
        if (!move_uploaded_file($photo_tmp, $photo_path)) {
            die("Failed to upload photo.");
        }
    }

    // Resume Parsing with Affinda
    $resume_data = [];
    if (!empty($_FILES['resume']['name'])) {
        $resume_tmp = $_FILES['resume']['tmp_name'];
        $resume_file = new CURLFile($resume_tmp, mime_content_type($resume_tmp), $_FILES['resume']['name']);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.affinda.com/v2/resumes");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ['file' => $resume_file]);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer aff_06f41013821cbecdba640e5eae07f836bf591e28",
            "Content-Type: multipart/form-data"
        ]);

        $response = curl_exec($ch);
        curl_close($ch);

        if ($response) {
            $result = json_decode($response, true);
            if (isset($result['data'])) {
                $resume_data = $result['data'];
            }
        }
    }

    // Personal Info (autofill from resume if available)
    $lastname = $_POST['lastname'] ?? ($resume_data['name']['family'] ?? '');
    $firstname = $_POST['firstname'] ?? ($resume_data['name']['given'] ?? '');
    $middlename = $_POST['middlename'] ?? '';
    $name_ext = $_POST['name_ext'] ?? '';
    $birthday = $_POST['birthday'] ?? '';
    $age = $_POST['age'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $civil_status = $_POST['civil_status'] ?? '';
    $religion = $_POST['religion'] ?? '';
    $nationality = $_POST['nationality'] ?? '';
    $email = $_POST['email'] ?? ($resume_data['emails'][0] ?? '');
    $address = $_POST['address'] ?? ($resume_data['location']['formatted'] ?? '');
    $personal_contact = $_POST['personal_contact'] ?? ($resume_data['phoneNumbers'][0] ?? '');
    $emergency_contact = $_POST['emergency_contact'] ?? '';

    // Academic Info
    $student_number = $_POST['student_number'] ?? '';
    $program = $_POST['program'] ?? '';
    $campus = $_POST['campus'] ?? '';
    $month_graduated = $_POST['month_graduated'] ?? '';
    $year_graduated = $_POST['year_graduated'] ?? '';
    $post_grad = $_POST['post_grad'] ?? '';
    $licensure_exam = $_POST['licensure_exam'] ?? '';
    $club_involvement = $_POST['club_involvement'] ?? '';

    // Employment Info (autofill from resume if available)
    $employment_status = $_POST['employment_status'] ?? '';
    $company = $_POST['company'] ?? ($resume_data['employment'][0]['organization'] ?? '');
    $industry = $_POST['industry'] ?? '';
    $position = $_POST['position'] ?? ($resume_data['employment'][0]['jobTitle'] ?? '');
    $employment_history = $_POST['employment_history'] ?? '';
    $previous_role = $_POST['previous_role'] ?? '';
    $length_of_service = $_POST['length_of_service'] ?? '';

    // Password & Consent
    $consent = isset($_POST['consent']) ? 1 : 0;
    $password = $_POST['password'] ?? '';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL
    $sql = "INSERT INTO itcp (
        photo, lastname, firstname, middlename, name_ext, birthday, age, gender,
        civil_status, religion, nationality, email, address, personal_contact, emergency_contact,
        student_number, program, campus, month_graduated, year_graduated, post_grad,
        licensure_exam, club_involvement, employment_status, company, industry, position,
        employment_history, previous_role, length_of_service, consent, password
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "ssssssisssssssssssisssssssssssis",
        $photo, $lastname, $firstname, $middlename, $name_ext, $birthday, $age, $gender,
        $civil_status, $religion, $nationality, $email, $address, $personal_contact, $emergency_contact,
        $student_number, $program, $campus, $month_graduated, $year_graduated, $post_grad,
        $licensure_exam, $club_involvement, $employment_status, $company, $industry, $position,
        $employment_history, $previous_role, $length_of_service, $consent, $hashed_password
    );

    if ($stmt->execute()) {
        echo "<script>alert('Alumni registration successful!'); window.location.href='al_login.php';</script>";
    } else {
        echo "Execute failed: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
