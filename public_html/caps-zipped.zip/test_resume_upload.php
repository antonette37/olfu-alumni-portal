<!DOCTYPE html>
<html>
<head>
    <title>Test Resume Upload</title>
    <style>
        body { font-family: Arial; max-width: 800px; margin: 20px auto; padding: 20px; }
        .result { margin-top: 20px; padding: 10px; border: 1px solid #ccc; }
    </style>
</head>
<body>
    <h2>Test Resume Upload</h2>
    <form id="uploadForm" enctype="multipart/form-data">
        <input type="file" name="resume" accept=".pdf,.doc,.docx" required>
        <button type="submit">Upload</button>
    </form>
    <div id="result" class="result"></div>

    <script>
        document.getElementById('uploadForm').onsubmit = function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const resultDiv = document.getElementById('result');
            
            resultDiv.innerHTML = 'Uploading...';
            
            fetch('parse_resume.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(text => {
                try {
                    const data = JSON.parse(text);
                    resultDiv.innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                } catch (e) {
                    resultDiv.innerHTML = 'Error parsing response: ' + text;
                }
            })
            .catch(error => {
                resultDiv.innerHTML = 'Error: ' + error.message;
            });
        };
    </script>
</body>
</html> 