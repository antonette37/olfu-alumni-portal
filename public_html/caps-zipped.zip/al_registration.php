<?php

$host = 'localhost';
$user = 'root';  
$pass = '';
$db = 'itcp_db';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /* photo */
    $photo = $_FILES['photo']['name'] ?? '';
    $photo_tmp = $_FILES['photo']['tmp_name'] ?? '';
    $photo_path = 'photos/' . basename($photo);
    if (!empty($photo)) {
        move_uploaded_file($photo_tmp, $photo_path);
    }

    /* personal information */
    $lastname = $_POST['lastname'] ?? '';
    $firstname = $_POST['firstname'] ?? '';
    $middlename = $_POST['middlename'] ?? '';
    $name_ext = $_POST['name_ext'] ?? '';
    $birthday = $_POST['birthday'] ?? '';
    $age = $_POST['age'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $civil_status = $_POST['civil_status'] ?? '';
    $religion = $_POST['religion'] ?? '';
    $nationality = $_POST['nationality'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $personal_contact = $_POST['personal_contact'] ?? '';
    $emergency_contact = $_POST['emergency_contact'] ?? '';

    /* academic information */
    $student_number = $_POST['student_number'] ?? '';
    $program = $_POST['program'] ?? '';
    $campus = $_POST['campus'] ?? '';
    $month_graduated = $_POST['month_graduated'] ?? '';
    $year_graduated = $_POST['year_graduated'] ?? '';
    $post_grad = $_POST['post_grad'] ?? '';
    $licensure_exam = $_POST['licensure_exam'] ?? '';
    $club_involvement = $_POST['club_involvement'] ?? '';

    /* employment information */
    $employment_status = $_POST['employment_status'] ?? '';
    $company = $_POST['company'] ?? '';
    $industry = $_POST['industry'] ?? '';
    $position = $_POST['position'] ?? '';
    $employment_history = $_POST['employment_history'] ?? '';
    $previous_role = $_POST['previous_role'] ?? '';
    $length_of_service = $_POST['length_of_service'] ?? '';

    /* login */
    $consent = isset($_POST['consent']) ? 1 : 0;
    $password = $_POST['password'] ?? '';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO itcp (
        photo, lastname, firstname, middlename, name_ext, birthday, age, gender,
        civil_status, religion, nationality, email, address, personal_contact, emergency_contact,
        student_number, program, campus, month_graduated, year_graduated, post_grad,
        licensure_exam, club_involvement, employment_status, company, industry, position,
        employment_history, previous_role, length_of_service, consent, password
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("SQL Error: " . $conn->error);
    }

    $stmt->bind_param("ssssssissssssssssssssssssssssis", 
    $photo, $lastname, $firstname, $middlename, $name_ext, $birthday, $age, $gender, 
    $civil_status, $religion, $nationality, $email, $address, $personal_contact, $emergency_contact, 
    $student_number, $program, $campus, $month_graduated, $year_graduated, $post_grad, 
    $licensure_exam, $club_involvement, $employment_status, $company, $industry, $position, 
    $employment_history, $previous_role, $length_of_service, $consent, $hashed_password
);


    if ($stmt->execute()) {
        echo "Registered!";
    } else {
        echo "Error executing query: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Registration</title>
    <link rel="stylesheet" href="al_registration_css.css">
</head>
<body>

<!-- Header -->
<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Registration</span>
    </div>
    <nav>
        <a href="al_home.html">Home</a>
        <a href="al_login.php">Log In</a>
        <a href="al_contact.php">Contact Us</a>
        <a href="gen_faqs.php">Help/FAQS</a>
    </nav>
</div>

<br><br><br>

<form action="al_registration_process.php" method="POST" enctype="multipart/form-data">
    <fieldset>
        <legend><h2> Upload photo </h2></legend>
        <legend><b>NOTE:</b><br>
            - Selfie photos, cropped photos, stolen shots, photos with blurry quality that are not in white background are NOT ACCEPTED. <br>
            - Avoid wearing spaghetti straps, off shoulder tops, and muscle sandos in your formal picture.</p></legend>
        <label for="photo">Upload Here:</label>
        <input type="file" name="photo" id="photo">


        <label for="resume">Upload Resume (PDF, DOCX):</label>
            <input type="file" name="resume" id="resume" accept=".pdf,.doc,.docx">
    </fieldset><br><br>

    <!-- Personal Information -->
    <fieldset>
        <legend><h2> Personal Information </h2></legend>

        <div class="name-row">
            <div class="name-group">
                <label for="lastname">Last Name:</label>
                <input type="text" name="lastname" id="lastname" required placeholder="Lastname">
            </div>

            <div class="name-group">
                <label for="firstname">First Name:</label>
                <input type="text" name="firstname" id="firstname" required placeholder="Firstname">
            </div>

            <div class="name-group">
                <label for="middlename">Middle Name:</label>
                <input type="text" name="middlename" id="middlename" placeholder="Middlename">
            </div>

            <div class="name-group">
                <label for="name_ext">Name Extension:</label>
                <input type="text" name="name_ext" id="name_ext" placeholder="JR, SR, III, IV, V">
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <label for="birthday">Birthday:</label>
                <input type="date" name="birthday" id="birthday" required>
            </div>
            
            <div class="info-group">
                <label for="age">Age:</label>
                <input type="text" name="age" id="age" required placeholder="Age">
            </div>

            <div class="gender-group">
                <label>Gender:</label>
                <div class="gender-options">
                    <input type="radio" name="gender" value="Male" id="gender_male" required>
                    <label for="gender_male">Male</label>
                    <input type="radio" name="gender" value="Female" id="gender_female">
                    <label for="gender_female">Female</label>
                </div>
            </div>

            <div class="info-group">
                <label for="civil_status">Civil Status:</label>
                <select name="civil_status" id="civil_status" required>
                    <option value="Select">-- select --</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                    <option value="Anulled">Anulled</option>
                    <option value="Separated">Separated</option>
                </select>
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <label for="religion">Religion:</label>
                <input type="text" name="religion" id="religion" required placeholder="Religion">
            </div>

            <div class="info-group">
                <label for="nationality">Nationality:</label>
                <input type="text" name="nationality" id="nationality" required placeholder="Nationality">
            </div>

            <div class="info-group">
                <label for="email">Email Address:</label>
                <input type="email" name="email" id="email" required placeholder="Personal Email Address">
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <label for="personal_contact">Personal Contact Number:</label>
                <input type="text" name="personal_contact" id="personal_contact" required placeholder="(09)">
            </div>

            <div class="info-group">
                <label for="emergency_contact">Emergency Contact Number:</label>
                <input type="text" name="emergency_contact" id="emergency_contact" required placeholder="(09)">
            </div>
        </div>

            <div class="info-group">
                <label for="emergency_contact">Home Address:</label>
                <input type="text" name="address" id="address" required placeholder="Present Address">
            </div>
        </div>
    </fieldset><br><br>

    <!-- Academic Information -->
    <fieldset>
        <legend><h2> Academic Information </h2></legend>
        <div class="info-row">
            <div class="info-group">
                <label for="student_number">Student Number:</label>
                <input type="text" name="student_number" id="student_number" required placeholder="Student Number">
            </div>

            <div class="info-group">
                <label for="program">Program:</label>
                <select name="program" id="program" placeholder="Program">
                    <option value="Select">-- select --</option>
                    <option value="BSIT">BSIT</option>
                    <option value="BSCE">BSCE</option>
                </select>
            </div>

            <div class="info-group">
                <label for="campus">Campus:</label>
                <select name="campus" id="campus" required placeholder="Campus">
                    <option value="Select">-- select --</option>
                    <option value="Antipolo Campus">Antipolo Campus</option>
                    <option value="Valenzuela Campus">Valenzuela Campus</option>
                    <option value="Quezon City Campus">Quezon City Campus</option>
                    <option value="Pampanga Campus">Pampanga Campus</option>
                    <option value="Nueva Ecija Campus">Nueva Ecija Campus</option>
                    <option value="Laguna Campus">Laguna Campus</option>
                </select>
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <label for="month_graduated">Month Graduated:</label>
                <input type="text" name="month_graduated" id="month_graduated" required placeholder="Month Graduated">
            </div>

            <div class="info-group">
                <label for="year_graduated">Year Graduated:</label>
                <input type="number" name="year_graduated" id="year_graduated" required placeholder="Year Graduated">
            </div>
        </div>

        <div class="info-row">
            <div class="info-group">
                <label for="post_grad">Post-Graduate Education:</label>
                <input type="text" name="post_grad" id="post_grad" placeholder="Post Graduate Education">
            </div>

            <div class="info-group">
                <label for="licensure_exam">Licensure Exam Taken:</label>
                <input type="text" name="licensure_exam" id="licensure_exam" placeholder="Licensure Exam Taken">
            </div>

            <div class="info-group">
                <label for="club_involvement">Club Involvement:</label>
                <input type="text" name="club_involvement" id="club_involvement" placeholder="Club Involvement">
            </div>
        </div>
    </fieldset><br><br>

    <!-- Employment Information -->
    <fieldset>
        <legend><h2> Employment Information </h2></legend>
        <label for="employment_status">Employment Status:</label>
        <select name="employment_status" id="employment_status" required placeholder="Employment Status">
            <option value ="Select"> -- select -- </option>
            <option value="Employed">Employed</option>
            <option value="Unemployed">Unemployed</option>
            <option value="Self Employed">Self Employed</option>
        </select><br><br>

        <div class="info-row">
    <div class="info-group">
        <label for="company">Company:</label>
        <input type="text" name="company" id="company" placeholder="Company">
    </div>

    <div class="info-group">
        <label for="industry">Industry:</label>
        <input type="text" name="industry" id="industry" placeholder="Industry">
    </div>

    <div class="info-group">
        <label for="position">Position:</label>
        <input type="text" name="position" id="position" placeholder="Current role in company">
    </div>
</div>

        <label for="employment_history">Employment History <h5>if applicable </h5></label>
        <input type="text" name="employment_history" id="employment_history" placeholder="Previous Company"><br><br>

        <div class="info-row">
    <div class="info-group">
        <label for="previous_role">Previous Role:</label>
        <input type="text" name="previous_role" id="previous_role" placeholder="Previous Role in Company">
    </div>

    <div class="info-group">
        <label for="length_of_service">Length of Service:</label>
        <input type="text" name="length_of_service" id="length_of_service" placeholder="Length of your service">
    </div>
</div>
    </fieldset><br><br>

    <!-- Password and Consent -->
    <fieldset>
        <legend><h3> Password and Consent </h3></legend>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required placeholder="Generate and Remember your password"><br><br>
        
        <label for="consent">
        <input type="checkbox" name="consent" id="consent" required>    
        I hereby consent to the release of all information and records indicated herewith in relevance to the 
        processing of my school credentials and employment. By affixing my signature, 
        I hereby allow the university and its accredited industry partners to use these information for 
        EMPLOYMENT and RESEARCH PURPOSES in accordance to the Republic Act No. 10173. 
        This consent shall remain in effect until I revoke it by submitting a written revocation to Our Lady of Fatima University.
        </label>
        <br>
        <button type="submit">Register</button>
    </fieldset>
</form>

</body>
</html>