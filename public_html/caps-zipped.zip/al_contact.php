<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="al_contact_css.css">
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Contact Us</span>
    </div>
    <nav>
        <a href="al_home.html">Home</a>
        <a href="gen_faqs.php">Help/FAQs</a>
    </nav>
</div>

<?php
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'success') {
        echo '<div class="message success">Your message has been sent successfully!</div>';
    } elseif ($_GET['status'] == 'error') {
        echo '<div class="message error">There was an error sending your message. Please try again.</div>';
    }
}
?>
<br><br><br><br><br><br><br><br>
<form method="POST" action="al_contact_process.php">
    <fieldset>
        <legend><h3>Contact Us</h3></legend>
        <p>Please fill up the form below and we'll get back to you soon!</p>

        <label for="firstname">Your Name:</label>
        <input type="text" name="firstname" id="firstname" required placeholder="Enter your Name">

        <label for="email">Email:</label>
        <input type="email" name="mail" id="mail" required placeholder="Enter your email">

        <label for="message">Your Message Concern to Us:</label>
        <textarea name="message" rows="5" required placeholder="Enter your message"></textarea>

        <button type="submit">Send Message</button>
    </fieldset>
</form>

</body>
</html>
