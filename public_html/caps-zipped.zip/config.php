<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "itpc_db"; // Database for ITPC system

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
