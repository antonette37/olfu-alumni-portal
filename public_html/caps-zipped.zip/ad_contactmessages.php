<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    header("Location: admin_login.php");
    exit();
}

$host = "localhost";
$dbname = "alumni_system";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$limit = 15;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_sql = $search ? "WHERE name LIKE ? OR email LIKE ?" : '';

$valid_columns = ['name', 'submitted_at'];
$sort_by = isset($_GET['sort']) && in_array($_GET['sort'], $valid_columns) ? $_GET['sort'] : 'submitted_at';
$order = (isset($_GET['order']) && strtolower($_GET['order']) === 'asc') ? 'ASC' : 'DESC';

$total_sql = "SELECT COUNT(*) AS total FROM contact_messages $search_sql";
$total_stmt = $conn->prepare($total_sql);
if ($search) {
    $search_param = "%" . $search . "%";
    $total_stmt->bind_param("ss", $search_param, $search_param);
}
$total_stmt->execute();
$total_result = $total_stmt->get_result();
$total_rows = $total_result ? $total_result->fetch_assoc()['total'] : 0;
$total_pages = ceil($total_rows / $limit);

$sql = "SELECT * FROM contact_messages $search_sql ORDER BY $sort_by $order LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
if ($search) {
    $stmt->bind_param("ssii", $search_param, $search_param, $limit, $offset);
} else {
    $stmt->bind_param("ii", $limit, $offset);
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Contact Messages</title>
    <link rel="stylesheet" href="ad_contactmessages_css.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Contacted Messages</span>
    </div>
    <nav>
      <a href="ad_home.html">Home</a>
        <a href="ad_dashboard.php">Dashboard</a>
        <a href="###">Messages</a>
        <a href="###">Notifications</a>
        <a href="ad_logout.php">Log Out</a>    
    </nav>
</div>

<h2>Submitted Contact Messages</h2>

<form method="get" style="margin-bottom: 20px;">
    <input type="text" name="search" placeholder="Search by name or email" value="<?= htmlspecialchars($search) ?>">
    <input type="submit" value="Search">
</form>

<?php if ($result && $result->num_rows > 0): ?>
<table>
    <tr>
        <th>
            <a href="?search=<?= urlencode($search) ?>&sort=name&order=<?= $sort_by === 'name' && $order === 'ASC' ? 'desc' : 'asc' ?>">
                Name
            </a>
        </th>
        <th>Email</th>
        <th>Message</th>
        <th>
            <a href="?search=<?= urlencode($search) ?>&sort=submitted_at&order=<?= $sort_by === 'submitted_at' && $order === 'ASC' ? 'desc' : 'asc' ?>">
                Date
            </a>
        </th>
    </tr>

    <?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
        <td><?= htmlspecialchars($row['submitted_at']) ?></td>
    </tr>
    <?php endwhile; ?>
</table>

<div class="pagination">
    <?php if ($page > 1): ?>
        <a href="?search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>&sort=<?= $sort_by ?>&order=<?= strtolower($order) ?>">&laquo; Prev</a>
    <?php endif; ?>

    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
        <a class="<?= $i == $page ? 'current' : '' ?>" href="?search=<?= urlencode($search) ?>&page=<?= $i ?>&sort=<?= $sort_by ?>&order=<?= strtolower($order) ?>"><?= $i ?></a>
    <?php endfor; ?>

    <?php if ($page < $total_pages): ?>
        <a href="?search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>&sort=<?= $sort_by ?>&order=<?= strtolower($order) ?>">Next &raquo;</a>
    <?php endif; ?>
</div>

<?php else: ?>
    <p>No messages found.</p>
<?php endif; ?>

</body>
</html>

<?php $conn->close(); ?>
