<?php
session_start();
session_unset();
session_destroy();
header('Location: co_login.php');
exit();
?>
