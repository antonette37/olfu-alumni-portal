<html lang="en">
 <head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1" name="viewport"/>
  <title>
   Fatima Alumni Events
  </title>
  <script src="https://cdn.tailwindcss.com">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&amp;display=swap" rel="stylesheet"/>
  <style>
   body {
      font-family: "Open Sans", sans-serif;
    }
  </style>
 </head>
 <body class="bg-white">
  <!-- HEADER -->
  <header class="bg-white shadow-md fixed top-0 left-0 right-0 z-50 border-t-4 border-green-900">
   <div class="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
    <div class="flex items-center space-x-3">
     <!-- Logo with link to al_homepage.php -->
        <a href="al_homepage.php">
          <img src="olfulogo.png" alt="Fatima Logo" class="h-10 w-10" />
        </a>
     <div>
      <h1 class="text-xl font-bold text-gray-800">
       Fatima Alumni
      </h1>
      <p class="text-sm text-gray-600">
       Our Lady of Fatima University
      </p>
     </div>
    </div>
    <nav class="flex items-center space-x-6 text-gray-700 font-medium">
     <a class="hover:text-green-700" href="al_directory.php">
      Find Alumni
     </a>
     <a class="hover:text-green-700" href="al_events.php">
      Events
     </a>
     <a class="hover:text-green-700" href="al_careers.php">
      Careers
     </a>
     <a class="hover:text-green-700" href="al_dashboard.php">
      Dashboard
     </a>
     <a class="hover:text-green-700" href="jobs.php">
      Jobs
     </a>
     <a class="hover:text-green-700" href="about.php">
      About
     </a>
     <a class="bg-green-700 text-white px-4 py-1.5 rounded-md hover:bg-green-800 font-semibold" href="logout.php">
      Logout
     </a>
    </nav>
   </div>
  </header>
   <!-- SIDEBAR -->
  <aside
    id="sidebar"
    class="bg-green-700 text-white w-16 hover:w-64 transition-all duration-300 fixed h-full z-40 overflow-hidden pt-20 group"
  >
    <!-- Hamburger remains visible -->
    <div class="flex items-center justify-center h-16">
      <i class="fas fa-bars text-2xl"></i>
    </div>
    <ul class="space-y-4 mt-6 pl-4 pr-4">
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="profile.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-user mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Profile</p>
            <p class="text-sm text-green-200">View and edit alumni profile</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="al_events.php" class="flex items-center space-x-4 w-full">
          <i class="fas fa-calendar mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Events</p>
            <p class="text-sm text-green-200">Upcoming alumni events</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="announcements.php#announcements"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-bullhorn mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Announcements</p>
            <p class="text-sm text-green-200">Recent news & updates</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a href="jobs.php#jobs" class="flex items-center space-x-4 w-full">
          <i class="fas fa-briefcase mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Job Board</p>
            <p class="text-sm text-green-200">Opportunities for alumni</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_calendar.php#calendar"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-calendar-alt mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Calendar</p>
            <p class="text-sm text-green-200">Event calendar overview</p>
          </div>
        </a>
      </li>
      <li
        class="flex items-start space-x-4 hover:bg-green-600 px-2 py-2 rounded transition cursor-pointer"
      >
        <a
          href="al_directory.php#directory"
          class="flex items-center space-x-4 w-full"
        >
          <i class="fas fa-address-book mt-1"></i>
          <div class="hidden group-hover:block">
            <p class="font-semibold">Directory</p>
            <p class="text-sm text-green-200">Connect with other alumni</p>
          </div>
        </a>
      </li>
    </ul>
  </aside>

  <!-- Main content -->
  <main class="max-w-7xl mx-auto px-4 py-6 flex flex-col sm:flex-row gap-6 pt-24 sm:pl-72">
   <!-- Left sidebar replaced by fixed sidebar, so no sidebar here -->
   <!-- Right content -->
   <section class="flex-grow flex flex-col gap-4">
    <!-- Event 1 -->
    <article aria-label="ITRS Recruitment Day event details" class="bg-white border border-gray-300 rounded flex flex-col sm:flex-row gap-4 p-3">
     <img alt="ITRS Recruitment Day banner showing city skyline and QR code" class="w-full sm:w-48 object-cover rounded" height="100" src="https://storage.googleapis.com/a1aa/image/0c1e15f2-6276-4783-9026-a1fe1c3d205f.jpg" width="200"/>
     <div class="flex flex-col flex-grow text-xs text-gray-700">
      <h3 class="font-semibold text-gray-900 mb-1">
       ITRS Recruitment Day (July 24, 2023)
      </h3>
      <div class="flex items-center space-x-2 mb-1">
       <i class="far fa-clock">
       </i>
       <time class="text-gray-600" datetime="2023-07-23">
        Starts: Jul 23, 2023
       </time>
      </div>
      <div class="flex items-center space-x-2 mb-1">
       <i class="far fa-clock">
       </i>
       <time class="text-gray-600" datetime="2023-07-28">
        Ends: Jul 28, 2023
       </time>
      </div>
      <div class="flex items-start space-x-2 mb-2">
       <i class="fas fa-map-marker-alt mt-1">
       </i>
       <address class="not-italic text-gray-600 leading-tight">
        Address: ITRS (Philis) Inc, 16th Floor, Tower 6789, 6789 Ayala Avenue,
              Makati City 1209, Philippines, Makati
       </address>
      </div>
      <span class="inline-block bg-gray-300 text-gray-600 text-[9px] px-2 py-0.5 rounded-full select-none">
       Past Event
      </span>
      <button class="ml-auto mt-2 bg-green-700 text-white text-xs font-semibold px-4 py-1 rounded hover:bg-green-800 self-start sm:self-auto" type="button">
       VIEW
      </button>
     </div>
     <button aria-label="Share ITRS Recruitment Day event" class="self-start sm:self-auto text-gray-600 hover:text-gray-900 p-1" type="button">
      <i class="fas fa-share-alt">
      </i>
     </button>
    </article>
    <!-- Event 2 -->
    <article aria-label="Texas Instruments Career Talk Session event details" class="bg-white border border-gray-300 rounded flex flex-col sm:flex-row gap-4 p-3">
     <img alt="Texas Instruments Career Talk Session banner with gears and text" class="w-full sm:w-48 object-cover rounded" height="100" src="https://storage.googleapis.com/a1aa/image/58e45147-2da9-4ca8-396e-b1f4656c0c36.jpg" width="200"/>
     <div class="flex flex-col flex-grow text-xs text-gray-700">
      <h3 class="font-semibold text-gray-900 mb-1">
       TEXAS INSTRUMENTS CAREER TALK SESSION
      </h3>
      <div class="flex items-center space-x-2 mb-1">
       <i class="far fa-clock">
       </i>
       <time class="text-gray-600" datetime="2023-05-03T03:30">
        Starts: May 03, 2023 - 3:30 AM
       </time>
      </div>
      <div class="flex items-center space-x-2 mb-1">
       <i class="far fa-clock">
       </i>
       <time class="text-gray-600" datetime="2023-05-04">
        Ends: May 04, 2023
       </time>
      </div>
      <div class="flex items-start space-x-2 mb-2">
       <i class="fas fa-map-marker-alt mt-1">
       </i>
       <address class="not-italic text-gray-600 leading-tight">
        SEMINAR ROOM (MAPUA UNIVERSITY - INTYRAMUROS), Intramuros
       </address>
      </div>
      <span class="inline-block bg-gray-300 text-gray-600 text-[9px] px-2 py-0.5 rounded-full select-none">
       Past Event
      </span>
      <button class="ml-auto mt-2 bg-green-700 text-white text-xs font-semibold px-4 py-1 rounded hover:bg-green-800 self-start sm:self-auto" type="button">
       VIEW
      </button>
     </div>
     <button aria-label="Share Texas Instruments Career Talk Session event" class="self-start sm:self-auto text-gray-600 hover:text-gray-900 p-1" type="button">
      <i class="fas fa-share-alt">
      </i>
     </button>
    </article>
    <!-- No more events -->
    <div aria-live="polite" class="bg-gray-200 text-gray-600 text-center text-xs py-1 select-none">
     No more events to display!
    </div>
   </section>
  </main>
 </body>
</html>
