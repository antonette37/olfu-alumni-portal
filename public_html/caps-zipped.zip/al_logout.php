<?php
session_start();
session_unset();
session_destroy(); 

// Redirect to the dynamic PHP homepage
header('Location: al_homepage.php');
exit();
?>
