<?php
session_start();

$admin_username = "admin";
$admin_password = "password";

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: ad_dashboard.php");
        exit();
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="ad_login_css.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University</h1>
        <span>Admin Log In</span>
    </div>
    <nav>
        <a href="ad_home.html">Home</a>
        <a href="###">User Log In</a>
        <a href="###">Forgot Password</a>
        <a href="gen_faqs.php">Help</a>
        <a href="gen_dashboard.php">Alumni Dashboard</a>
    </nav>
</div>

<?php
if (!empty($error_message)) {
    echo "<center><div style='color:red; font-weight:bold;'>$error_message</div></center><br>";
}
?>

<center>
    <form action="ad_login.php" method="POST">
        <fieldset>
            <legend><h3>Login with Username and Password</h3></legend>

            <label for="username">Username:</label>
            <input type="text" name="username" id="username" required placeholder="Admin's Username"><br><br>

            <label for="password">Password:</label>
            <input type="password" name="password" id="password" required placeholder="Admin Password"><br><br>

            <button type="submit">Login</button>
        </fieldset>
    </form>

    <fieldset>
        <div class="signup-link">
            <p>Don't have admin account? <a href="#">Contact Shaira!</a></p>
        </div>
    </fieldset>
</center>

</body>
</html>
