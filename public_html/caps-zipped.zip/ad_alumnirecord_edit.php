<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$database = "itcp_db"; 

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'] ?? null;
if (!$id) {
    echo "Select user to edit.";
    exit;
}

$result = $conn->query("SELECT * FROM itcp WHERE id = $id");
if (!$result || $result->num_rows === 0) {
    echo "Alumni record not found.";
    exit;
}
$alumni = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fields = [
        'lastname', 'firstname', 'middlename', 'name_ext', 'birthday', 'age', 'gender',
        'civil_status', 'religion', 'nationality', 'email', 'address',
        'personal_contact', 'emergency_contact', 'student_number', 'program',
        'campus', 'month_graduated', 'year_graduated', 'post_grad',
        'licensure_exam', 'club_involvement', 'employment_status', 'company',
        'industry', 'position', 'employment_history', 'previous_role', 'length_of_service', 'consent'
    ];

    $values = [];
    foreach ($fields as $field) {
        $values[$field] = $_POST[$field] ?? '';
    }

    $set_clause = implode(', ', array_map(fn($f) => "$f = ?", $fields));
    $types = str_repeat('s', count($fields)) . 'i';
    $params = array_values($values);
    $params[] = $id;

    $stmt = $conn->prepare("UPDATE itcp SET $set_clause WHERE id = ?");
    if (!$stmt) {
        echo "Prepare failed: " . $conn->error;
        exit;
    }

    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        header("Location: ad_alumnirecord.php");
        exit;
    } else {
        echo "Error updating record: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Alumni Record</title>
    <link rel="stylesheet" href="ad_alumnirecord_edit_css.css">
</head>
<body>

<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Edit Alumni Record</span>
    </div>
    <nav>
        <a href="ad_home.html">Home</a>
        <a href="ad_dashboard.php">Dashboard</a>
        <a href="###">Messages</a>
        <a href="###">Notifications</a>
        <a href="ad_logout.php">Log Out</a>
    </nav>
</div>

<form method="post"> <br>

    <!-- PERSONAL INFORMATION -->
    <fieldset>
        <legend>PERSONAL INFORMATION</legend>
        <table>
            <?php
            $fields_personal = [
                'lastname', 'firstname', 'middlename', 'name_ext', 'birthday', 'age', 'gender',
                'civil_status', 'religion', 'nationality', 'email', 'address',
                'personal_contact', 'emergency_contact'
            ];
            foreach ($fields_personal as $i => $field) {
                if ($i % 2 === 0) echo "<tr>";
                echo "<td><label>" . ucfirst(str_replace('_', ' ', $field)) . ":</label>";
                echo "<input type='text' name='$field' value='" . htmlspecialchars($alumni[$field]) . "'></td>";
                if ($i % 2 === 1) echo "</tr>";
            }
            ?>
        </table>
    </fieldset>

    <!-- ACADEMIC INFORMATION -->
    <fieldset>
        <legend>ACADEMIC INFORMATION</legend>
        <table>
            <?php
            $fields_academic = [
                'student_number', 'program', 'campus', 'month_graduated', 'year_graduated',
                'post_grad', 'licensure_exam', 'club_involvement'
            ];
            foreach ($fields_academic as $i => $field) {
                if ($i % 2 === 0) echo "<tr>";
                echo "<td><label>" . ucfirst(str_replace('_', ' ', $field)) . ":</label>";
                echo "<input type='text' name='$field' value='" . htmlspecialchars($alumni[$field]) . "'></td>";
                if ($i % 2 === 1) echo "</tr>";
            }
            ?>
        </table>
    </fieldset>

    <!-- EMPLOYMENT INFORMATION -->
    <fieldset>
        <legend>EMPLOYMENT INFORMATION</legend>
        <table>
            <?php
            $fields_employment = [
                'employment_status', 'company', 'industry', 'position', 'employment_history',
                'previous_role', 'length_of_service'
            ];
            foreach ($fields_employment as $i => $field) {
                if ($i % 2 === 0) echo "<tr>";
                echo "<td><label>" . ucfirst(str_replace('_', ' ', $field)) . ":</label>";
                echo "<input type='text' name='$field' value='" . htmlspecialchars($alumni[$field]) . "'></td>";
                if ($i % 2 === 1) echo "</tr>";
            }
            ?>
        </table>
    </fieldset>

    <!-- CONSENT -->
    <fieldset>
        <legend>CONSENT</legend>
        <label>Consent:</label>
        <select name="consent">
            <option value="Yes" <?= $alumni['consent'] == 'Yes' ? 'selected' : '' ?>>Yes</option>
            <option value="No" <?= $alumni['consent'] == 'No' ? 'selected' : '' ?>>No</option>
        </select>
    </fieldset>

    <button type="submit">Update Alumni</button>
</form>

</body>
</html>
