<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="ad_dashboard_css.css">
</head>
<body>

  <div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Admin Dashboard</span>
    </div>
    <nav>
      <a href="ad_home.html">Home</a>
      <a href="ad_dashboard.php">Dashboard</a>
      <a href="###">Messages</a>
      <a href="###">Notifications</a>
      <a href="ad_logout.php">Log Out</a>
    </nav>
  </div>

  <div class="container">
    <div class="sidebar">
      <h3><strong>SHAIRA MAE BUENSUCESO BASIGA</strong></h3>
      <a href="###">User Account Management</a>
      <a href="###">Content Management</a>
      <a href="###">Profile</a>
      <a href="ad_calendar.php">Calendar</a>
      <a href="ad_alumnirecord.php">Alumni Records</a>
      <a href="ad_alumnidirectory.php">Alumni Directory</a>
      <a href="###">Registration Analytics</a>
      <a href="###">Logs</a>
      <a href="###">Contact Messages</a>
      <a href="###">Requests</a>
    </div>
    <div class="main-content">
      <h2>ANNOUNCEMENTS AND EVENTS</h2>
    </div>

  </div>

</body>
</html>
