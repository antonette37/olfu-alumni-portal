<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMS</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="al_homepage_css.css">
</head>
<body class="min-h-screen bg-white text-gray-800">
    <!-- Header -->
    <header class="bg-white shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                <!-- Logo and Title -->
                <div class="flex items-center space-x-4">
                    <!-- Logo with link to al_homepage.php -->
                    <a href="al_homepage.php">
                        <img src="olfulogo.png" alt="OLFU Logo" class="h-12 w-12 object-contain" />
                    </a>
                    <div>
                        <h1 class="text-xl font-bold text-gray-800 leading-tight">Alumni Management System</h1>
                        <p class="text-sm text-gray-500">Our Lady of Fatima University</p>
                    </div>
                </div>

                <!-- Navigation -->
                <nav class="hidden md:flex space-x-6">
                    <a href="al_directory.php" class="text-gray-700 hover:text-green-700 font-medium transition">Find Alumni</a>
                    <a href="#" class="text-gray-700 hover:text-green-700 font-medium transition">Events</a>
                    <a href="#" class="text-gray-700 hover:text-green-700 font-medium transition">Careers</a>
                    <a href="al_dashboard.php" class="text-gray-700 hover:text-green-700 font-medium transition">Dashboard</a>
                    <a href="#" class="text-gray-700 hover:text-green-700 font-medium transition">Jobs</a>
                    <a href="#" class="text-gray-700 hover:text-green-700 font-medium transition">About</a>
                    <button id="loginBtn" class="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded">Login</button>
                </nav>
            </div>
        </div>

        <!-- Mobile Menu Button (Optional Enhancement) -->
        <div class="md:hidden flex items-center">
            <button class="text-gray-700 hover:text-green-700 focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>
    </header>

    <!-- Search Section -->
    <section class="text-white py-20 bg-cover bg-center" style="background-image: url('alumni_bg.png');">
        <div class="container mx-auto text-center bg-black bg-opacity-60 p-10 rounded-lg">
            <h2 class="text-4xl font-bold mb-8">IDK IF LEAVE AS IS</h2>
            <form action="search.php" method="POST" class="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            </form>
        </div>
    </section>

    <!-- Info Cards -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                <h3 class="text-xl font-semibold mb-3 text-gray-800">Alumni Network</h3>
                <p class="text-gray-600">Connect with fellow graduates, share experiences, and expand your professional network.</p>
            </div>
            <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                <h3 class="text-xl font-semibold mb-3 text-gray-800">Upcoming Events</h3>
                <p class="text-gray-600">Stay updated on reunions, workshops, and networking opportunities tailored for our community.</p>
            </div>
            <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                <h3 class="text-xl font-semibold mb-3 text-gray-800">Student Resources</h3>
                <p class="text-gray-600">Access a wealth of resources to support your academic journey and career development.</p>
            </div>
        </div>
    </section>

    <!-- Networking Section -->
    <section class="bg-green-100 py-16">
        <div class="container mx-auto">
            <h3 class="text-3xl font-bold mb-10 text-center text-gray-800">Networking Opportunities</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                    <h4 class="text-xl font-semibold mb-3 text-gray-800">Alumni Mixers</h4>
                    <p class="text-gray-600">Join our regular alumni mixers to connect with professionals in various industries.</p>
                </div>
                <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                    <h4 class="text-xl font-semibold mb-3 text-gray-800">Industry Panels</h4>
                    <p class="text-gray-600">Attend panels featuring successful alumni sharing insights from their career journeys.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Career Section -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto">
            <h3 class="text-3xl font-bold mb-10 text-center text-gray-800">Career Guidance</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                    <h4 class="text-xl font-semibold mb-3 text-gray-800">Career Counseling</h4>
                    <p class="text-gray-600">Get personalized career advice from our experienced counselors to help you navigate your professional path.</p>
                </div>
                <div class="bg-white rounded-xl shadow-md p-6 transition-transform duration-300 hover:shadow-xl hover:scale-105 cursor-pointer">
                    <h4 class="text-xl font-semibold mb-3 text-gray-800">Skills Workshops</h4>
                    <p class="text-gray-600">Enhance your skills with our workshops covering topics from resume writing to interview techniques.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-8">
        <div class="container mx-auto text-center">
            <p>&copy; 2025 Our Lady of Fatima University. All rights reserved.</p>
            <div class="mt-4">
                <a href="#" class="text-blue-300 hover:text-blue-100 mx-2">Privacy Policy</a>
                <a href="#" class="text-blue-300 hover:text-blue-100 mx-2">Terms of Service</a>
                <a href="#" class="text-blue-300 hover:text-blue-100 mx-2">Contact Us</a>
            </div>
        </div>
    </footer>

    <!-- Login Modal -->
    <div id="loginModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden flex items-center justify-center z-50">
        <div class="bg-white p-8 rounded-lg shadow-lg w-full max-w-md relative">
            <h2 class="text-2xl font-bold mb-4 text-green-600">Login to Your Account</h2>
            
            <div class="mb-4">
                <button id="studentTabBtn" class="bg-green-500 text-white px-4 py-2 rounded-l">Student</button>
                <button id="alumniTabBtn" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-r">Alumni</button>
            </div>

            <!-- Error message -->
            <p id="loginMessage" class="text-red-600 text-sm mb-4"></p>

            <form id="loginForm" method="POST">
                <input type="hidden" id="userType" name="userType" value="student">
                <div class="mb-4">
                    <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                    <input type="email" id="email" name="email" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                <div class="mb-6">
                    <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                    <input type="password" id="password" name="password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline" required>
                </div>
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Sign In
                    </button>
                    <button type="button" id="closeModalBtn" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                        Close
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const loginBtn = document.getElementById('loginBtn');
            const loginModal = document.getElementById('loginModal');
            const closeModalBtn = document.getElementById('closeModalBtn');
            const studentTabBtn = document.getElementById('studentTabBtn');
            const alumniTabBtn = document.getElementById('alumniTabBtn');
            const loginForm = document.getElementById('loginForm');
            const loginMessage = document.getElementById('loginMessage');
            const emailInput = document.getElementById('email');
            const userTypeInput = document.getElementById('userType');

            // Open modal
            loginBtn.addEventListener('click', function () {
                loginModal.classList.remove('hidden');
                document.body.classList.add('modal-open');
                loginMessage.textContent = '';
            });

            // Close modal
            closeModalBtn.addEventListener('click', function () {
                loginModal.classList.add('hidden');
                document.body.classList.remove('modal-open');
                loginMessage.textContent = '';
            });

            // Close modal if clicking outside the form
            loginModal.addEventListener('click', function (e) {
                if (e.target === loginModal) {
                    loginModal.classList.add('hidden');
                    document.body.classList.remove('modal-open');
                    loginMessage.textContent = '';
                }
            });

            // Tab switching
            studentTabBtn.addEventListener('click', function () {
                studentTabBtn.classList.add('bg-green-500', 'text-white');
                studentTabBtn.classList.remove('bg-gray-300', 'text-gray-700');
                alumniTabBtn.classList.remove('bg-green-500', 'text-white');
                alumniTabBtn.classList.add('bg-gray-300', 'text-gray-700');
                emailInput.placeholder = 'student@example.com';
                userTypeInput.value = 'student';
            });

            alumniTabBtn.addEventListener('click', function () {
                alumniTabBtn.classList.add('bg-green-500', 'text-white');
                alumniTabBtn.classList.remove('bg-gray-300', 'text-gray-700');
                studentTabBtn.classList.remove('bg-green-500', 'text-white');
                studentTabBtn.classList.add('bg-gray-300', 'text-gray-700');
                emailInput.placeholder = 'alumni@example.com';
                userTypeInput.value = 'alumni';
            });

            // Form submission
            loginForm.addEventListener('submit', async function (e) {
                e.preventDefault();

                loginMessage.textContent = 'Signing in...';

                const formData = new FormData(loginForm);

                try {
                    const response = await fetch('al_login.php', {
                        method: 'POST',
                        body: formData
                    });

                    const result = await response.json();

                    if (result.status === 'success') {
                        window.location.href = 'al_dashboard.php';
                    } else {
                        loginMessage.textContent = result.message || 'Login failed.';
                    }
                } catch (error) {
                    loginMessage.textContent = 'An error occurred. Please try again.';
                    console.error('Login error:', error);
                }
            });
        });
    </script>
</body>
</html>