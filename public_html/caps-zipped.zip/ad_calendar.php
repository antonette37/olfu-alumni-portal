<head>
    <link rel="stylesheet" href="al_calendar_css.css">
</head>

<body>
<div class="header">
    <img src="olfulogo.png" alt="OLFU Logo">
    <div class="title">
        <h1>Our Lady of Fatima University </h1>
        <span>Calendar</span>
    </div>
    <nav>
        <a href="ad_home.html">Home</a>
        <a href="ad_dashboard.php">Dashboard</a>
        <a href="ad_logout.php">Log Out</a>
    </nav>
</div>
<div class="container">
    <aside class="sidebar">
        <nav class="sidebar-nav">
            
    <a href="###">User Account Management</a>
    <a href="###">Content Management</a>
    <a href="###">Profile</a>
    <a href="ad_calendar.php">Calendar</a>
    <a href="ad_alumnirecord.php">Alumni Records</a>
    <a href="ad_alumnidirectory.php">Alumni Directory</a>
    <a href="###">Registration Analytics</a>
    <a href="###">Logs</a>
    <a href="###">Contact Messages</a>
    <a href="###">Requests</a>
        </nav>
    </aside>
</body>

<?php
$month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
$first_day_of_month = mktime(0, 0, 0, $month, 1, $year);
$days_in_month = date('t', $first_day_of_month);
$month_name = date('F', $first_day_of_month);
$starting_day = date('w', $first_day_of_month);

echo "<table border='1' cellpadding='5' cellspacing='0'>";
echo "<tr>";
echo "<th><a href='?month=" . ($month - 1) . "&year=$year'>&lt;</a></th>"; 
echo "<th colspan='5'>$month_name $year</th>";
echo "<th><a href='?month=" . ($month + 1) . "&year=$year'>&gt;</a></th>";
echo "</tr>";
echo "<tr>";
echo "<th>Sunday</th> <th>Monday</th> <th>Tuesday</th> <th>Wednesday</th> <th>Thursday</th> <th>Friday</th> <th>Saturday</th>";
echo "</tr>";

$day_of_week = 0;
echo "<tr>";

for ($i = 0; $i < $starting_day; $i++) {
    echo "<td></td>";
    $day_of_week++;
}

for ($day = 1; $day <= $days_in_month; $day++) {
    echo "<td>$day</td>";
    $day_of_week++;

    if ($day_of_week == 7) {
        echo "</tr><tr>";
        $day_of_week = 0;
    }
}

while ($day_of_week < 7) {
    echo "<td></td>";
    $day_of_week++;
}

echo "</tr>";
echo "</table>";
?>
